﻿/*
 * Grid-MonK is an open source softwaer application intended to annalize power grids, esepcially microgrids
 * The basic variant works by invoking the OpenDSS open-source application, with input files prepared by Grid_MonK
 * and export output files read by OpenDSS and used for further calulations and for interracting with a grid specialist.
 * Grid-Monk can be used and modified by anybody, the only condition is to keep these comments unchanged in the upper
 * part of the used or modified application
 * There is no guarrantee given for any functionality or for any
 * influence on the computer(s) running this applications or on other applications which run on the computer(s)
 * Initiator of the Grid-Monk application: Mihai Sanduleac, University Politehnica of Bucharest, Romania
 * This moduel is initially developed to implement Hardware in the loop (HIL) functionality in Storage4Grid H2020 project for the Romanian use-case
 * Contributors: Mihai Sanduleac, Andrei Tudose
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft;
using Newtonsoft.Json;
using System.IO;
using System.Diagnostics;

namespace GridMonC
{
    public partial class GridMonk : Form
    {
        //Client mosqsub/17072-RPI-TEST0 received PUBLISH (d0, q0, r0, m0, '/LESSAg/SMX/LESSAg_ER_Data', ... (61 bytes))
        // {"ER_mode":"0.0","P_BAT_real":"0.0","PPv":"0.0","SoC":"-123.27959""P_CONS":"0"}
        // {"ER_mode":"3.0","PBat":"0.0","PBat_set":"80.0","PPv":"0.09655807","SoC":"20.0","UPv":"1.1810849","Ubat":"91.700745"}
        // {"ER_mode":"3.0","Ibat":"0.0","PBat":"0.0","PBat_set":"80.0","PGrid":"-52.073196","PPv":"0.12612382","QGrid":"-66.43855","SoC":"20.0","UPv":"1.6599782","Ubat":"91.65485"}
        // {"ER_PGrid":"-55.0563","ER_QGrid":"-70.068085","ER_UGrid":"265.18634","ER_mode":"3.0","Ibat":"0.0","PBat":"0.0","PBat_set":"80.0","PPv":"0.15351124","SMXDateTime":"11/26/2019 20:08:50","SoC":"20.0","UPv":"2.4245253","Ubat":"91.708405"}
        // {"ER_PGrid":"-51.937653","ER_QGrid":"-73.473145","ER_UGrid":"265.6218","ER_mode":"3.0","Ibat":"0.0","PBat":"0.0","PBat_set":"80.0","PPv":"0.13027498","SMXDateTime":"11/26/2019 20:15:15","SoC":"20.0","U1_PCC":"223.9","UPv":"1.4696689","Ubat":"91.679245"}
        // {"ER_PGrid":"-52.553516","ER_QGrid":"-71.67967","ER_UGrid":"262.57367","ER_mode":"3.0","Ibat":"0.0","PBat":"0.0","PBat_set":"80.0","PPv":"0.22794218","SMXDateTime":"11/26/2019 20:21:15","SoC":"20.0","U1_PCC":"224.0","UPv":"2.2500453","Ubat":"91.66137"}
        // {"ER_PGrid":"-54.8513","ER_QGrid":"-70.34186","ER_UGrid":"254.8808","ER_mode":"3.0","IBat":"0.0","PBat":"0.0","PBat_set":"80.0","PPv":"0.19908737","SMXDateTime":"11/26/2019 20:30:30","SoC":"20.0","U1_PCC":"224.3","U2_PCC":"222.0","U3_PCC":"225.70000000000002","UBat":"91.70719","UPv":"2.0962303"}
        // {"ER_PGrid":"-56.307663","ER_QGrid":"-70.771324","ER_UGrid":"262.7188","ER_mode":"3.0","IBat":"0.0",
        //    "P1_PCC":"232","P2_PCC":"0","P3_PCC":"94","PBat":"0.0","PBat_set":"80.0","PPv":"0.15338075","Q1_PCC":"182","Q2_PCC":"0","Q3_PCC":"76",
        //    "SMXDateTime":"11/26/2019 20:37:10","SoC":"20.0","U1_PCC":"224.10000000000002","U2_PCC":"222.3","U3_PCC":"225.9",
        //    "UBat":"91.68706","UPv":"1.8634341"}
        // {"Am_PCC":"18556.100000000002","Ap_PCC":"7165997.100000001","ER_PGrid":"-53.064434","ER_QGrid":"-72.39636","ER_UGrid":"250.81664",
        //    "ER_mode":"3.0","IBat":"0.0","P1_PCC":"233","P2_PCC":"0","P3_PCC":"633","PBat":"0.0","PBat_set":"80.0","PPv":"0.14650382",
        //    "Q1_PCC":"182","Q2_PCC":"0","Q3_PCC":"13","Rm_PCC":"3404277.4000000004","Rp_PCC":"11365.2","SMXDateTime":"11/26/2019 20:43:35",
        //    "SoC":"20.0","U1_PCC":"224.10000000000002","U2_PCC":"222.3","U3_PCC":"224.5","UBat":"91.70137","UPv":"1.7798858"}
        // {"Am_PCC":"18556.100000000002","Ap_PCC":"7166062.800000001","ER_PGrid":"-59.999847","ER_QGrid":"-68.20898","ER_UGrid":"261.55762",
        //     "ER_mode":"3.0","IBat":"0.0","K1_PCC":"0.78","K2_PCC":"2.0","K3_PCC":"0.77","P1_PCC":"232","P2_PCC":"0","P3_PCC":"94",
        //     "PBat":"0.0","PBat_set":"80.0","PPv":"0.16463186","P_PCC":"327","Q1_PCC":"183","Q2_PCC":"0","Q3_PCC":"77","Q_PCC":"259",
        //     "Rm_PCC":"3404307.3000000003","Rp_PCC":"11365.2","SMXDateTime":"11/26/2019 20:52:25","SoC":"20.0",
        //     "U1_PCC":"224.70000000000002","U2_PCC":"222.8","U3_PCC":"226.5","UBat":"91.69916","UPv":"1.8572586","f_PCC":"49.900000000000006"}
        // {"Am_PCC":"18556.100000000002","Ap_PCC":"7166117.600000001","ER_PGrid":"-51.833862","ER_QGrid":"-73.50863","ER_UGrid":"278.68515",
        //     "ER_mode":"3.0","IBat":"0.0","K1_PCC":"0.78","K2_PCC":"2.0","K3_PCC":"0.77","P1_PCC":"233","P2_PCC":"0","P3_PCC":"94",
        //     "PBat":"0.0","PBat_set":"80.0","PPv":"0.08411516","P_PCC":"328","Q1_PCC":"183","Q2_PCC":"0","Q3_PCC":"76","Q_PCC":"258",
        //     "Rm_PCC":"3404350.5","Rp_PCC":"11365.2","SMM_Time_PCC":"11/26/2019 21:59:12","SMXCpuLoad_PCC":"4.03","SMXCpuTemp_PCC":"51.5",
        //     "SMXDateTime_PCC":"11/26/2019 21:02:25","SoC":"20.0","U1_PCC":"225.20000000000002","U2_PCC":"223.0","U3_PCC":"226.8",
        //     "UBat":"91.67081","UPv":"1.1070814","f_PCC":"49.900000000000006"}
        /*
            {"Am_PCC":"18558.9","Ap_PCC":"7216156.800000001","ER_PGrid":"-75.08131","ER_QGrid":"-72.28873","ER_UGrid":"270.99228",
            "ER_mode":"3.0","IBat":"-0.26651138","K1_PCC":"0.79","K2_PCC":"2.0","K3_PCC":"0.99",
            "LESSAg_ER_Mode_cd":"[{\"v\":3.0,\"u\":\"\", \"t\":0, \"n\":\"\"}]","LESSAg_ER_PBat_cd":"[{\"v\":-25.0,\"u\":\"\", \"t\":0, \"n\":\"\"}]",
            "LESSAg_ER_QGrid_cd":"[{\"v\":0.0,\"u\":\"\", \"t\":0, \"n\":\"\"}]","P1_PCC":"233","P2_PCC":"0","P3_PCC":"191","PBat":"-25.18127",
            "PBat_set":"-25.0","PPv":"0.11794956","P_PCC":"424","Q1_PCC":"177","Q2_PCC":"0","Q3_PCC":"14","Q_PCC":"163","Rm_PCC":"3430897.6",
            "Rp_PCC":"11373.2","SMM_Time_PCC":"12/01/2019 19:35:55","SMXCpuLoad_PCC":"4.40","SMXCpuTemp_PCC":"52.599998474121094",
            "SMXDateTime_PCC":"12/01/2019 18:39:10","SoC":"44.355858","U1_PCC":"222.5","U2_PCC":"220.70000000000002","U3_PCC":"225.0",
            "UBat":"94.48479","UPv":"1.5523927","f_PCC":"50.0"}


         */



        public class LESSAg_ER_Data
        {
            [DefaultValue("0.0")]
            [JsonProperty("ER_PGrid", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String ER_PGrid_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("ER_QGrid", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String ER_QGrid_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("ER_UGrid", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String ER_UGrid_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("ER_mode", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String ER_mode { get; set; } 

            [DefaultValue("0.0")]
            [JsonProperty("PBat", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P_BAT_real_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("UBat", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String U_BAT_real_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("IBat", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String I_BAT_real_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("PBat_set", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P_BAT_setpoint_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("PPv", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P_PV_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("UPv", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String U_PV_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("SoC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String SoC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("LESSAg_ER_PBat_cd", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String LESSAg_ER_PBat_cd { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("LESSAg_ER_QGrid_cd", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String LESSAg_ER_QGrid_cd { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("LESSAg_ER_Mode_cd", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String LESSAg_ER_Mode_cd { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("U1_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String U1_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("U2_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String U2_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("U3_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String U3_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("P_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("P1_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P1_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("P2_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P2_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("P3_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String P3_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("Q_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Q_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("Q1_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Q1_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("Q2_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Q2_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("Q3_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Q3_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("Ap_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Ap_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("Am_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Am_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("Rp_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Rp_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("Rm_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String Rm_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("K1_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String K1_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("K2_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String K2_PCC_MQTT { get; set; }
            [DefaultValue("0.0")]
            [JsonProperty("K3_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String K3_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("f_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String f_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("SMXDateTime_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String SMXDateTime_PCC_MQTT { get; set; }
            
            [DefaultValue("0.0")]
            [JsonProperty("SMM_Time_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String SMM_Time_PCC_MQTT { get; set; }

            [DefaultValue("0.0")]
            [JsonProperty("SMXCpuTemp_PCC", DefaultValueHandling = DefaultValueHandling.Populate)]
            public String SMXCpuTemp_PCC_MQTT { get; set; }
            

            //[DefaultValue("0.0")]
            //[JsonProperty("P_CONS_MQTT", DefaultValueHandling = DefaultValueHandling.Populate)]
            //public String P_CONS_MQTT { get; set; }
        }
        // {"ER_mode":"3.0","PBat":"79.41042","PPv":"12.247213","SoC":"43.433002"}
        string er_mode;
        double P_BAT_real_MQTT = 0, P_PV_MQTT = 0, U_PV_MQTT = 0, SoC_MQTT = 0, P_CONS_MQTT = 0;
        double P_BAT_setpoint_MQTT = 0, U_BAT_real_MQTT = 0, I_BAT_MQTT = 0;
        string LESSAg_ER_PBat_cd = "";
        string LESSAg_ER_QGrid_cd = "";
        string LESSAg_ER_Mode_cd = "";
        double U1_PCC_MQTT = 0, U2_PCC_MQTT = 0, U3_PCC_MQTT = 0;
        double P_PCC_MQTT = 0, P1_PCC_MQTT = 0, P2_PCC_MQTT = 0, P3_PCC_MQTT = 0;
        double Q_PCC_MQTT = 0, Q1_PCC_MQTT = 0, Q2_PCC_MQTT = 0, Q3_PCC_MQTT = 0;
        double K1_PCC_MQTT = 0, K2_PCC_MQTT = 0, K3_PCC_MQTT = 0;
        double f_PCC_MQTT = 0;
        double Ap_PCC_MQTT = 0, Am_PCC_MQTT = 0, Rp_PCC_MQTT = 0, Rm_PCC_MQTT = 0;
        double P_PCC = 0, P_PV_after_curtail = 0, P_PV_meteo = 0, P_PV_curtail=0;
        string SMXDateTime_PCC_MQTT = "", SMM_Time_PCC_MQTT = "";
        double SMXCpuTemp_PCC_MQTT = 0;

        int MQTT_Received_messages = 0;
        int MQTT_Received_and_filtered_messages = 0;

        // LESSAg/ER/ER_Mode = [{"v":3.0,"u":"", "t":0, "n":""}]
        // LESSAg/ER/PBat = [{"v":40.0,"u":"", "t":0, "n":""}]
        // LESSAg/ER/QGrid = [{"v":0.0,"u":"", "t":0, "n":""}]
        string topic1 = "";
        string payload1 = "";
        //string topic1 = "LESSAg/ER/PBat/Cd";
        //string payload1 = "[{\"v\":40.0,\"u\":\"\", \"t\":0, \"n\":\"\"}]";

        const int S4G_var_max_number = 10, S4G_var_max_prop = 4;
        string[,] S4G_var = new string[S4G_var_max_number, S4G_var_max_prop];
        const int S4G_var_PROP_P_bat_setp = 0;
        const int S4G_var_PROP_Q_grid_setp = 1;
        const int S4G_var_PROP_ER_mode_setp = 3;

        void MQTT_Published_Data_S4G()
        {
            if((topic1 != "") && (payload1 != ""))
            {
                MQTT_publish(topic1, payload1, 1);
                topic1 = ""; payload1 = ""; // the strings become back empty, such that only a new command will generate 
            }
        }

        void MQTT_Received_Data_S4G(MqttMsgPublishEventArgs e)
        {
            Debug.WriteLine("Received = " + Encoding.UTF8.GetString(e.Message) + " on topic " + e.Topic);
            message_received = Encoding.UTF8.GetString(e.Message);
            MQTT_Received_messages++;
            if (e.Topic == "/LESSAg/SMX/LESSAg_ER_Data")
            {
                var serializer = new JsonSerializer();
                LESSAg_ER_Data res = serializer.Deserialize<LESSAg_ER_Data>(new JsonTextReader(new StringReader(Encoding.UTF8.GetString(e.Message))));

                MQTT_Received_and_filtered_messages++;

                er_mode = res.ER_mode;
                P_BAT_real_MQTT = Convert.ToDouble(res.P_BAT_real_MQTT);
                P_BAT_setpoint_MQTT = Convert.ToDouble(res.P_BAT_setpoint_MQTT);
                U_BAT_real_MQTT = Convert.ToDouble(res.U_BAT_real_MQTT);
                I_BAT_MQTT = Convert.ToDouble(res.I_BAT_real_MQTT);
                P_PV_MQTT = Convert.ToDouble(res.P_PV_MQTT);
                U_PV_MQTT = Convert.ToDouble(res.U_PV_MQTT);
                SoC_MQTT = Convert.ToDouble(res.SoC_MQTT);
                LESSAg_ER_PBat_cd = res.LESSAg_ER_PBat_cd;
                LESSAg_ER_QGrid_cd = res.LESSAg_ER_QGrid_cd;
                LESSAg_ER_Mode_cd = res.LESSAg_ER_Mode_cd;

                U1_PCC_MQTT = Convert.ToDouble(res.U1_PCC_MQTT);
                U2_PCC_MQTT = Convert.ToDouble(res.U2_PCC_MQTT);
                U3_PCC_MQTT = Convert.ToDouble(res.U3_PCC_MQTT);

                P_PCC_MQTT = Convert.ToDouble(res.P_PCC_MQTT);
                P1_PCC_MQTT = Convert.ToDouble(res.P1_PCC_MQTT);
                P2_PCC_MQTT = Convert.ToDouble(res.P2_PCC_MQTT);
                P3_PCC_MQTT = Convert.ToDouble(res.P3_PCC_MQTT);

                Q_PCC_MQTT = Convert.ToDouble(res.Q_PCC_MQTT);
                Q1_PCC_MQTT = Convert.ToDouble(res.Q1_PCC_MQTT);
                Q2_PCC_MQTT = Convert.ToDouble(res.Q2_PCC_MQTT);
                Q3_PCC_MQTT = Convert.ToDouble(res.Q3_PCC_MQTT);

                Ap_PCC_MQTT = Convert.ToDouble(res.Ap_PCC_MQTT);
                Am_PCC_MQTT = Convert.ToDouble(res.Am_PCC_MQTT);
                Rp_PCC_MQTT = Convert.ToDouble(res.Rp_PCC_MQTT);
                Rm_PCC_MQTT = Convert.ToDouble(res.Rm_PCC_MQTT);

                K1_PCC_MQTT = Convert.ToDouble(res.K1_PCC_MQTT);
                K2_PCC_MQTT = Convert.ToDouble(res.K2_PCC_MQTT);
                K3_PCC_MQTT = Convert.ToDouble(res.K3_PCC_MQTT);

                f_PCC_MQTT = Convert.ToDouble(res.f_PCC_MQTT);

                SMXDateTime_PCC_MQTT = res.SMXDateTime_PCC_MQTT;
                SMM_Time_PCC_MQTT = res.SMM_Time_PCC_MQTT;

                SMXCpuTemp_PCC_MQTT = Convert.ToDouble(res.SMXCpuTemp_PCC_MQTT);
                

            }
        }
        
        const int mode_DiskFile = 0; //data comes from a file located on disk
        const int mode_LOOP = 1; //data comes from a software loop, as follows: input(t)=output(t-1)
        const int mode_MQTTmessage = 2; //data comes from a real process via MQTT messages


        string activate_S4G_HIL = "no";
        string PROC_S4G_data_path = "";
        string LESSAg_project_name = "";
        string P_CONS_profile_file_name = "";

        string P_CONS_profile_forecast_24h__file_name = "";
        double P_CONS_profile_forecast_factor = 1;
        double P_CONS_profile_forecast_time_period = 1;


        string P_PV_profile_meteo_foreacst_24h_file_name = "";
        double P_PV_profile_meteo_forecast_24h_factor = 1;
        double PV_forecast_time_period = 1;

        string Battery_forecast_24h_file_name = "";


        string sim_type = "fullday";
        int sim_time = -1;//default value =0, means the algorithm is going to run until the end of day
        const int simulation_until_end_of_day = -1;
        double[] P_CONS_profile = new double[86400];
        int P_cons_time_period = 1;

        double[] P_PV_meteo_profile = new double[86400];
        int P_PV_time_period = 1;
        string P_PV_profile_meteo_file_name = "";
        
        string EMS_strategy = "";
        double P_BAT_cd_setpoint;
        double P_BAT_real;
        double P_CONS;
        double P_BAT_max_inverters;
        double P_Cons_SeTpoint = 500;
        double Battery_charging_efficiency = 1;
        double Battery_discharging_efficiency = 1;
        string battery_limitation = "";
        int battery_mode = 0;
        double E_bat = 0;
        double E_bat_nominal = 0;
        double E_bat_max = 0;
        double E_bat_min = 0;
        double SoC = 0;
        double SoC_init = 0;
        int T_integration=0;
        int nr_tot_logs = 0;

        //Meter variables
        double Meter_E_BAT_real_charging = 0; // Wh
        double Meter_E_BAT_real_discharging = 0; // Wh
        double P_PCC_Ap = 0; // meter index A plus
        double P_PCC_Am = 0; // meter index A minus
        double P_CONS_Ap = 0;
        double P_PV_meteo_Am = 0;
        double P_PV_after_curtail_Am = 0;
        double P_PV_curtail_Am = 0; // PV energy curtailed

        double PV_time_period = 1;
        double PV_scaling_factor = 1;
        int P_PV_profile_meteo_shift = 0; // in hours
        double bat_scaling_factor = 1;
        double bat_time_period = 1;
        double Cons_time_period = 1;
        double Cons_scaling_factor = 1;

        int process_time_period = 1;

        int P_cons_mode;
        int P_PV_meteo_mode;
        int P_PV_after_curtail_mode, P_bat_mode, SoC_mode, P_PV_curtail_mode;
        // P_CONS and P_PV_METEO and (forecasts!!!!) can be in one of the following modes:
        //0 - data comes from a file located on disk (pre-recorded data)
        //1 - data comes from a "software loop" (the input value at current time(t) is the output value at time t-1)
        //2 - data comes as MQTT messages from a real process (hardware in the loop). In this mode, output values at time t may differ from input values at time t+1
        double[] P_bat_in = new double[86400];
        double[] P_bat_out = new double[86400];
        double[] P_PV_curtail_in = new double[86400];
        double[] P_PV_curtail_out = new double[86400];
        double[] P_PV_meteo_in = new double[86400];
        double[] P_PV_meteo_out = new double[86400];
        double[] SoC_in = new double[86400];
        double[] SoC_out = new double[86400];
        double[] P_CONS_in = new double[86400];
        double[] P_CONS_out = new double[86400];
        double[] P_CONS_Profile_forecast_24h = new double[86400];//!!!!!!!!!!!!!!!!!!!!1
        double[] P_PV_profile_meteo_forecast_24h = new double[86400];//!!!!!!!!!!!!!!!!!!!!!!!
        int PCC_injection_allowed = 0; //Default=0: we are not allowed to be in injection mode towards the system. P_PCC is always positive. PV curtailment is applied in order to realise this

        private void Paint_Prosumer(object sender, PaintEventArgs e)
        {
            string s1 = "";
            int x0 = 0;
            int y0 = 0;
            if (((prosumers[0, prosumers_PROP_x0]) != null) && ((prosumers[0, prosumers_PROP_x0]) != "")) x0 = int.Parse(prosumers[0, prosumers_PROP_x0]);
            if (((prosumers[0, prosumers_PROP_y0]) != null) && ((prosumers[0, prosumers_PROP_y0]) != "")) y0 = int.Parse(prosumers[0, prosumers_PROP_y0]);
            Graphics g = e.Graphics;

            // Clipping the plygones start lines
            GraphicsPath path_clip = new GraphicsPath();
            path_clip.AddPolygon(polyPoints_clip_scheme_zone);
            Region region = new Region(path_clip);            // Set the clipping region of the Graphics object.
            e.Graphics.SetClip(region, CombineMode.Replace);

            s1 = "SoC= " + SoC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 20);
            s1 = "P_BAT= " + P_BAT_real_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 40);
            s1 = "P_BAT_setp= " + P_BAT_setpoint_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 60);
            s1 = "U_BAT= " + U_BAT_real_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 80);
            s1 = "I_BAT= " + I_BAT_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 100);
            // U_BAT_real_MQTT
            s1 = "P_PV= " + P_PV_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 130);
            s1 = "U_PV= " + U_PV_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 150);

            s1 = "ER_MODE=" + er_mode;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 180);

            s1 = "RCV1=" + MQTT_Received_messages.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 210);
            s1 = "RCV2=" + MQTT_Received_and_filtered_messages.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 230);

            s1 = "Pbat_cd=" + LESSAg_ER_PBat_cd;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 260);
            s1 = "Qgrd_cd=" + LESSAg_ER_QGrid_cd;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 280);
            s1 = "ER_md_cd=" + LESSAg_ER_Mode_cd;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 10, y0 + 300);

            s1 = "U1_PCC=" + U1_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 20);
            s1 = "U2_PCC=" + U2_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 40);
            s1 = "U3_PCC=" + U3_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 60);

            s1 = "P_PCC=" + P_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 90);
            s1 = "P1_PCC=" + P1_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 110);
            s1 = "P2_PCC=" + P2_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 130);
            s1 = "P3_PCC=" + P3_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 150);

            s1 = "Q_PCC=" + Q_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 180);
            s1 = "Q1_PCC=" + Q1_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 200);
            s1 = "Q2_PCC=" + Q2_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 220);
            s1 = "Q3_PCC=" + Q3_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 130, y0 + 240);

            s1 = "Ap_PCC=" + Ap_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 20);
            s1 = "Am_PCC=" + Am_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 40);
            s1 = "Rp_PCC=" + Rp_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 60);
            s1 = "Rm_PCC=" + Rm_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 80);

            s1 = "K1_PCC=" + K1_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 110);
            s1 = "K2_PCC=" + K2_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 130);
            s1 = "K3_PCC=" + K3_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 150);

            s1 = "f_PCC=" + f_PCC_MQTT.ToString();
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 180);

            s1 = "Date1=" + SMXDateTime_PCC_MQTT;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 210);
            s1 = "Date2=" + SMM_Time_PCC_MQTT;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 230);
            s1 = "Temp=" + SMXCpuTemp_PCC_MQTT;
            g.DrawString(s1, Font1, b5DarkBlue, x0 + 230, y0 + 250);
            
        }


        public void Battery_command()
        {
            // Simulation of the battery behavior
            if (E_bat >= E_bat_max) if (P_BAT_cd_setpoint > 0) P_BAT_real = 0;
            double E_plus_max; // Maximum energy quantity possible to be introduced in the battery in the next timey step, in charging mode
            double E_minus_max; // Maximum energy quantity possible to be extracted from the battery in the next timey step, in discharging mode

            if (P_BAT_cd_setpoint >= 0)
            {
                // We check that the new setpoint, if positive (consumption/chraging mode), will not exceed the total energy of the battery
                if (P_BAT_cd_setpoint < P_BAT_real) E_plus_max = P_BAT_real * 1 / 3600; else E_plus_max = P_BAT_cd_setpoint * 1 / 3600; //!!!!!!!!!!! posibil sa fie nevoie de bat_time_period in loc de 3600

                if (E_bat < E_bat_max - E_plus_max)
                {
                    P_BAT_real = P_BAT_cd_setpoint;
                    battery_mode = 1; // charging mode
                } // simulare ER, partea de baterie
                else
                {
                    P_BAT_real = 0; P_BAT_cd_setpoint = 0;
                    battery_mode = 0; // idle mode
                }
                if (P_BAT_cd_setpoint == 0) battery_mode = 0;
            }
            else
            {
                // P_BAT_cd_setpoint<0, meaning we have an order to discharge/produce energy from battery
                // We check that the new setpoint, if negative (produce/discharge mode), will not go below minimum energy accepted for the the battery
                if (P_BAT_cd_setpoint > P_BAT_real) E_minus_max = P_BAT_real * 1 / 3600; else E_minus_max = P_BAT_cd_setpoint * 1 / 3600;

                if (E_bat + E_minus_max >= E_bat_min)
                {
                    P_BAT_real = P_BAT_cd_setpoint; // simulare ER, partea de baterie
                    battery_mode = 2; // discharging/production mode
                }
                else
                {
                    P_BAT_real = 0; P_BAT_cd_setpoint = 0;
                    battery_mode = 0; // idle mode
                }
            }

            battery_limitation = "";
            if (P_BAT_real >= 0)
            {
                if (P_BAT_real > P_BAT_max_inverters)
                {
                    P_BAT_real = P_BAT_max_inverters;
                    battery_limitation = " (Lim+)";
                }
            }
            else
            {
                if (P_BAT_real < -P_BAT_max_inverters)
                {
                    P_BAT_real = -P_BAT_max_inverters;
                    battery_limitation = " (Lim-)";
                }
            }
            // Battery energy is obtained by integration, considering also effciency for chargind and discharging
            if (P_BAT_real >= 0) E_bat = E_bat + P_BAT_real * T_integration / 3600 * Battery_charging_efficiency;
            else E_bat = E_bat + P_BAT_real * T_integration / 3600 * Battery_discharging_efficiency;

            SoC = E_bat / E_bat_max;
            //P_PCC = - P_PV_meteo - P_BAT_real -P_CONS; // simulare retea inetrna prosumer

        }

        double sim_start_time; //variable used to select the right data from files when in RealTime
        double[] Battery_forecast_24h = new double[87600];
        private void PROC_ini_S4G()
        {
            // read S4G config file "PROC_S4G_config_file.txt"
            // read consumption_file, scaling factor, time-period for a Pcons record (1s, 5s, 60s) 
            // PV_production_file, scaling factor, scaling factor, time-period for a PPv record (1s, 5s, 60s) 
            //
            for (int i1 = 0; i1 < S4G_var_max_number; i1++) for (int j1 = 0; j1 < S4G_var_max_prop; j1++) S4G_var[i1, j1] = "";
            string[] lines = System.IO.File.ReadAllLines("PROC_S4G_config_file.txt");
            foreach (string line in lines)
            {
                if (line[0] != '#')
                {
                    char[] delimiters_Level1 = { ';' };
                    string[] cmds = line.Split(delimiters_Level1);
                    foreach (string cmd in cmds)
                    {
                        char[] delimiters_Level2 = { '=', '[', ']' }; 
                        string[] line1 = cmd.Split(delimiters_Level2); 
                        if (line1[0].ToLower() == "activate_s4g_hil") activate_S4G_HIL = line1[1];
                        if (line1[0].ToLower() == "proc_s4g_data_path") PROC_S4G_data_path = line1[1];
                        if (line1[0].ToLower() == "lessag_project_name") LESSAg_project_name = line1[1];
                        if (line1[0].ToLower() == "ems_strategy") EMS_strategy = line1[1];
                        if (line1[0].ToLower() == "sim_type") sim_type = line1[1];
                        if (line1[0].ToLower() == "sim_time") sim_time = Convert.ToInt16(line1[1]);

                        if (line1[0].ToLower() == "p_cons_profile_file_name") P_CONS_profile_file_name = line1[1];

                        if (line1[0].ToLower() == "p_pv_profile_meteo_file_name") P_PV_profile_meteo_file_name = line1[1];
                        if (line1[0].ToLower() == "p_pv_profile_meteo_shift") P_PV_profile_meteo_shift = Convert.ToInt16(line1[1]);

                        if (line1[0].ToLower() == "p_cons_profile_forecast_24h__file_name") P_CONS_profile_forecast_24h__file_name = line1[1];
                        if (line1[0].ToLower() == "p_cons_profile_forecast_factor") P_CONS_profile_forecast_factor = double.Parse(line1[1]); 
                        if (line1[0].ToLower() == "p_cons_profile_forecast_time_period") P_CONS_profile_forecast_time_period = Convert.ToDouble(line1[1]);

                        if (line1[0].ToLower() == "p_pv_profile_meteo_foreacst_24h_file_name") P_PV_profile_meteo_foreacst_24h_file_name = line1[1];
                        if (line1[0].ToLower() == "p_pv_profile_meteo_forecast_24h_factor") P_PV_profile_meteo_forecast_24h_factor = double.Parse(line1[1]); 
                        if (line1[0].ToLower() == "pv_forecast_time_period") PV_forecast_time_period = Convert.ToDouble(line1[1]);

                        if (line1[0].ToLower() == "battery_forecast_24h_file_name") Battery_forecast_24h_file_name = line1[1];

                        if (line1[0].ToLower() == "e_bat_nominal") E_bat_nominal = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "e_bat_max") E_bat_max = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "e_bat_min") E_bat_min = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "soc_init") SoC_init = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "t_integration") T_integration = Convert.ToInt16(line1[1]); // this is  process time period
                        if (line1[0].ToLower() == "p_bat_max_inverters") P_BAT_max_inverters = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "battery_discharging_efficiency") Battery_discharging_efficiency = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "battery_charging_efficiency") Battery_charging_efficiency = Convert.ToDouble(line1[1]);

                        if (line1[0].ToLower() == "bat_scaling_factor") bat_scaling_factor = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "bat_time_period") bat_time_period = Convert.ToDouble(line1[1]);

                        if (line1[0].ToLower() == "cons_scaling_factor") Cons_scaling_factor = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "cons_time_period") Cons_time_period = Convert.ToDouble(line1[1]);

                        if (line1[0].ToLower() == "pv_scaling_factor") PV_scaling_factor = Convert.ToDouble(line1[1]);
                        if (line1[0].ToLower() == "pv_time_period") PV_time_period = Convert.ToDouble(line1[1]);

                        if (line1[0].ToLower() == "pcc_injection_allowed") PCC_injection_allowed = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "p_cons_mode") P_cons_mode = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "p_pv_meteo_mode") P_PV_meteo_mode = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "p_pv_after_curtail_mode") P_PV_after_curtail_mode = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "p_pv_curtail_mode") P_PV_curtail_mode = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "p_bat_mode") P_bat_mode = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "soc_mode") SoC_mode = Convert.ToInt16(line1[1]);
                        if (line1[0].ToLower() == "process_time_period") process_time_period = Convert.ToInt16(line1[1]); //!!!!!!!!!!!!!!!!!!!!!!!!! de lucrat aici....
                    }
                }
            }
            
            int nr_lines = 0;
            if (P_cons_mode == 0)
            {
                // ****** read the entire "P_CONS_profile" file
                lines = System.IO.File.ReadAllLines(PROC_S4G_data_path + P_CONS_profile_file_name);
                foreach (string line in lines)
                {
                    // Use a tab to indent each line of the file.
                    char[] delimiterChars = { '\t', '[' };
                    string[] line1 = line.Split(delimiterChars);
                    int pos = 0;
                    foreach (string s in line1)
                    {
                        //if ((pos == 2) && (nr_lines != 0)) {
                        if ((pos == 2) && (nr_lines != 0))
                        {
                            P_CONS_profile[nr_lines - 1] = double.Parse(s);
                            P_CONS_profile[nr_lines - 1] = P_CONS_profile[nr_lines - 1];
                        }
                        pos++;
                    }
                    nr_lines++;
                }
            }
            // ****** read the entire "P_PV_profile_meteo" file
            nr_lines = 0;
            if (P_PV_meteo_mode == 0)
            {
                lines = System.IO.File.ReadAllLines(PROC_S4G_data_path + P_PV_profile_meteo_file_name);
                foreach (string line in lines)
                {
                    // Use a tab to indent each line of the file.
                    char[] delimiterChars = { '\t', '[' };
                    string[] line1 = line.Split(delimiterChars);
                    int pos = 0;
                    foreach (string s in line1)
                    {
                        //if ((pos == 2) && (nr_lines != 0)) {
                        if ((pos == 2) && (nr_lines != 0))
                        {
                            P_PV_meteo_profile[nr_lines - 1] = double.Parse(s);
                            P_PV_meteo_profile[nr_lines - 1] = P_PV_meteo_profile[nr_lines - 1];
                        }
                        pos++;
                    }
                    nr_lines++;
                }
                //Shifting the meteo profile if the data was measured on a different time zone
                int pv_tot_logs = Convert.ToInt16(86400 / PV_time_period);
                int shift_profile = Convert.ToInt16(P_PV_profile_meteo_shift * 3600 / PV_time_period);
                for (int i1 = 0; i1 < pv_tot_logs - shift_profile; i1++)
                    P_PV_meteo_profile[pv_tot_logs - i1] = P_PV_meteo_profile[pv_tot_logs - shift_profile - i1];
            }
            // ****** read the entire "P_CONS_profile_forecast_24h" file
            nr_lines = 0;
            if (P_CONS_profile_forecast_24h__file_name != "") 
            {
                lines = System.IO.File.ReadAllLines(PROC_S4G_data_path + P_CONS_profile_forecast_24h__file_name);
                foreach (string line in lines)
                {
                    char[] delimiterChars = { '\t', '[' };
                    string[] line1 = line.Split(delimiterChars);
                    int pos = 0;
                    foreach (string s in line1)
                    {
                        if (pos == 2 && (nr_lines != 0))
                        {
                            P_CONS_Profile_forecast_24h[nr_lines-1] = double.Parse(s) * P_CONS_profile_forecast_factor;
                        }
                        pos++;
                    }
                    nr_lines++;
                }
            }
            // ****** read the entire "P_PV_profile_meteo_foreacst_24" file in a string variable
            nr_lines = 0;
            if (P_PV_profile_meteo_foreacst_24h_file_name != "")
            {
                lines = System.IO.File.ReadAllLines(PROC_S4G_data_path + P_PV_profile_meteo_foreacst_24h_file_name);
                foreach (string line in lines)
                {
                    char[] delimiterChars = { '\t', '[' };
                    string[] line1 = line.Split(delimiterChars);
                    int pos = 0;
                    foreach (string s in line1)
                    {
                        if (pos == 2 && (nr_lines != 0))
                        {
                            P_PV_profile_meteo_forecast_24h[nr_lines-1] = double.Parse(s) * P_PV_profile_meteo_forecast_24h_factor;
                        }
                        pos++;
                    }
                    nr_lines++;
                }
                //Shifting the meteo profile if the data was measured on a different time zone
                int pv_tot_logs = Convert.ToInt16(86400 / PV_time_period);
                int shift_profile = Convert.ToInt16(P_PV_profile_meteo_shift * 3600 / PV_time_period);
                for (int i1 = 0; i1 < pv_tot_logs - shift_profile; i1++)
                    P_PV_profile_meteo_forecast_24h[pv_tot_logs - i1] = P_PV_profile_meteo_forecast_24h[pv_tot_logs - shift_profile - i1];
            }
            // ****** read the entire "P_PV_profile_meteo_foreacst_24" file in a string variable
            nr_lines = 0;
            if (Battery_forecast_24h_file_name != "")
            {
                lines = System.IO.File.ReadAllLines(PROC_S4G_data_path + Battery_forecast_24h_file_name);
                foreach (string line in lines)
                {
                    char[] delimiterChars = { '\t', '[' };
                    string[] line1 = line.Split(delimiterChars);
                    int pos = 0;
                    foreach (string s in line1)
                    {
                        if (pos == 2 && (nr_lines != 0)) //pos=????????????????????????????????????
                        {
                            Battery_forecast_24h[nr_lines - 1] = double.Parse(s);
                        }
                        pos++;
                    }
                    nr_lines++;
                }
            }
            //determine the starting point of the simulation
            if (sim_type.ToLower() == "realtime")
            {
                sim_start_time = DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second; //the current second at the start of simulation
                sim_start_time = Math.Ceiling(sim_start_time / T_integration); // process begins at the current time
                //
                //
                //
                //
                //timer3_PROC.Interval=  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! durata refresh este de aprox 350 ms. Trebuie tinut cont de asta
                // posibil ca timer.interval= T_integration?! (avut grija ca interval este in milisecunde si T_integ in sec )               
            }
            else if (sim_type.ToLower() == "fullday")
            {
                sim_start_time = 0; //process starts at 00:00:00
            }

            //Pre process schedules (as in Unircon)
            //
            if (EMS_strategy == "Battery_forecast_optimized")
            {
            }
            if (EMS_strategy == "UniRCon")
            {
            }
            if (EMS_strategy == "PV_forecast_driven")//?????????????????
            {
                int bat_tot_logs = Convert.ToInt16(86400 / bat_time_period);
                for(int i = 0; i < bat_tot_logs; i++)
                {
                    double aux = bat_time_period / PV_forecast_time_period * i;
                    Battery_forecast_24h[i] = - P_PV_profile_meteo_forecast_24h[Convert.ToInt16(Math.Truncate(aux))];
                }

            }
            if (EMS_strategy== "PV_CONS_forecast_driven")
            {
                int bat_tot_logs = Convert.ToInt16(86400 / bat_time_period);
                //bat_time_period
                for (int i = 0; i < bat_tot_logs; i++)
                {
                    double aux_pv = bat_time_period / PV_forecast_time_period * i;
                    double aux_cons= bat_time_period / P_CONS_profile_forecast_time_period * i;
                    Battery_forecast_24h[i] = -P_PV_profile_meteo_forecast_24h[Convert.ToInt16(Math.Truncate(aux_pv))] - P_CONS_Profile_forecast_24h[Convert.ToInt16(Math.Truncate(aux_cons))];
                }
            }
                
            S4G_start_time = DateTime.Now;
        }

        DateTime S4G_start_time;   
        DateTime t_S4G;
        DateTime t_S4G_1;
        int S4G_HIL_LESSAg_dt;
        int S4G_HIL_dt;
        TimeSpan S4G_HIL_timer;
        int S4G_HIL_counter = 0;
        string[,] PROC_log_S4G = new string[84600, 16];
        const int counter_pos = 0;
        const int datetime_pos = 1;
        const int time_elapsed_pos = 2;
        const int p_cons_pos = 3;
        const int p_pv_meteo_pos = 4;
        const int p_pv_after_curtail_pos = 5;
        const int p_bat_real_pos = 6;
        const int SoC_pos = 7;
        const int p_pcc_pos = 8;
        const int p_bat_setpoit_pos = 9;
        

        private void timer3_PROC_S4G(object sender, EventArgs e)
        {
            t_S4G_1 = DateTime.Now;
            // Main loop of LESSAg (Local Energy Storage System Agent)

            // We process ER_mode, PBat, PPv, SoC, Pcons

            // We write in the PROC log file all important data, on a line: Date-Time, ER_mode, PBat, PPv, SoC

            // *************************** LESSAg algorithm start **************************
            if (SoC_mode == mode_LOOP) // 1
            {
                if (S4G_HIL_counter == 0) SoC_in[S4G_HIL_counter] = SoC_init;
                else SoC_in[S4G_HIL_counter] = SoC_out[S4G_HIL_counter - 1];
            }
            else if (SoC_mode == mode_MQTTmessage)  // 2 = prin MQTT 
            {
                SoC_in[S4G_HIL_counter] = SoC_MQTT;
            }
            SoC = SoC_in[S4G_HIL_counter];
            E_bat = SoC * E_bat_max;

            if (P_cons_mode == mode_DiskFile)
            {
                double aux = T_integration / Cons_time_period * (sim_start_time + S4G_HIL_counter); // !!!!!!!!!!!!!!!!!!!!! de gandit pentru per de esantionare mai mare decat T_integration
                //Prezent: iau P masurat la un mom de timp si nu tin cont de valorile masurate in urma
                P_CONS_in[S4G_HIL_counter] = P_CONS_profile[Convert.ToInt16(Math.Truncate(aux))] * Cons_scaling_factor;
            }
            else if (P_cons_mode == mode_MQTTmessage) P_CONS_in[S4G_HIL_counter] = P_CONS_MQTT * Cons_scaling_factor;//??????????????
            P_CONS = P_CONS_in[S4G_HIL_counter];

            if (P_PV_meteo_mode == mode_DiskFile)
            {
                double aux = T_integration / PV_time_period * (sim_start_time + S4G_HIL_counter); 
                P_PV_meteo_in[S4G_HIL_counter] = P_PV_meteo_profile[Convert.ToInt16(Math.Truncate(aux))] * PV_scaling_factor;
            }
            else if (P_PV_meteo_mode == mode_MQTTmessage) P_PV_meteo_in[S4G_HIL_counter] = P_PV_MQTT * PV_scaling_factor; //?????????????????????????? cum sa fac scalarea 
            P_PV_meteo = P_PV_meteo_in[S4G_HIL_counter];

            if (P_PV_curtail_mode == mode_LOOP)
            {
                if (S4G_HIL_counter == 0) P_PV_curtail_in[S4G_HIL_counter] = 0;
                else P_PV_curtail_in[S4G_HIL_counter] = P_PV_curtail_out[S4G_HIL_counter - 1];
            }
            else if (P_PV_curtail_mode == mode_MQTTmessage) P_PV_curtail_in[S4G_HIL_counter] = P_PV_MQTT * PV_scaling_factor;//???????????????? Pt timpul real ar trebuie sa citim P_PV_after_curtail
            P_PV_curtail = P_PV_curtail_in[S4G_HIL_counter];

            if (P_bat_mode == mode_LOOP)
            {
                if (S4G_HIL_counter == 0) P_bat_in[S4G_HIL_counter] = 0;
                else P_bat_in[S4G_HIL_counter] = P_bat_out[S4G_HIL_counter - 1];
            }
            else if (P_bat_mode == mode_MQTTmessage) P_bat_in[S4G_HIL_counter] = P_BAT_real_MQTT * bat_scaling_factor;
            P_BAT_real = P_bat_in[S4G_HIL_counter];

            P_PV_after_curtail = P_PV_meteo - P_PV_curtail;
            P_PCC = P_CONS + P_PV_after_curtail + P_BAT_real;

            if (EMS_strategy == "Battery_forecast_optimized")
            {
                double aux = T_integration / bat_time_period * (sim_start_time + S4G_HIL_counter);
                P_BAT_cd_setpoint = Battery_forecast_24h[Convert.ToInt16(Math.Truncate(aux))] * bat_scaling_factor;
                Battery_command();
            }
            if (EMS_strategy == "PV_forecast_driven")
            {
                double aux = T_integration / bat_time_period * (sim_start_time + S4G_HIL_counter);
                P_BAT_cd_setpoint = Battery_forecast_24h[Convert.ToInt16(Math.Truncate(aux))] * bat_scaling_factor;
                Battery_command();
            }
            if (EMS_strategy == "PV_CONS_forecast_driven")
            {
                double aux = T_integration / bat_time_period * (sim_start_time + S4G_HIL_counter);
                P_BAT_cd_setpoint = Battery_forecast_24h[Convert.ToInt16(Math.Truncate(aux))] * bat_scaling_factor;
                Battery_command();
            }
            if (EMS_strategy == "UniRCon")
            {
                if (P_PCC < 0)
                {
                    // We are in injection (production) mode towards DSO, so we need to take AP measures
                    // we try as first measure to increase battery consumption
                    P_BAT_cd_setpoint = P_BAT_real - P_PCC;
                }
                else
                {
                    // We are in consumption mode from DSO point of view
                    if (P_PV_curtail == 0)
                    {
                        // we do not have previous curtailment, so we can eventually command the battery to charge (consume = positive Power)
                        if (P_PCC > P_Cons_SeTpoint) P_BAT_cd_setpoint = P_BAT_cd_setpoint + P_Cons_SeTpoint - P_PCC;
                        //else P_BAT_cd_setpoint = 0;//P_BAT_real;
                        else P_BAT_cd_setpoint = P_BAT_real;
                        //if (P_BAT_cd_setpoint > P_PCC_contract) P_BAT_cd_setpoint = P_PCC_contract;
                        if (P_BAT_cd_setpoint > P_BAT_max_inverters * 1.1) P_BAT_cd_setpoint = P_BAT_max_inverters * 1.1;
                        if (P_BAT_cd_setpoint < -P_BAT_max_inverters * 1.1) P_BAT_cd_setpoint = -P_BAT_max_inverters * 1.1;
                    }
                    else
                    {
                        // we have previous curtail on PV, so we can reduce the curtailment with the value of P_PCC
                        if (P_PV_curtail < 0)
                        {
                            if (P_PV_curtail + P_PCC <= 0) P_PV_curtail = P_PV_curtail + P_PCC;
                            else P_PV_curtail = 0;
                        }

                    }
                }
                // give an order to the battery to take the new setpoint; however, if battery full, new setpoint might be not considered
                Battery_command();
                // calculate again P_PCC with the P_BAT_real after battery constraints have been considerede in Battery_command
                P_PCC = P_CONS + P_PV_after_curtail + P_BAT_real;
                if (PCC_injection_allowed == 0)
                {
                    if (P_PCC < 0) P_PV_curtail = P_PV_curtail + P_PCC; //else P_PV_curtail = 0;
                }
                P_PV_after_curtail = P_PV_meteo - P_PV_curtail;
                // we recalculate P_PCC
                P_PCC = P_CONS + P_PV_after_curtail + P_BAT_real;

            }
            // ************* Integrations (meters) ************* //
            // Metering (energy index calculated by integrating powers)
            if (P_BAT_real >= 0) Meter_E_BAT_real_charging = Meter_E_BAT_real_charging + P_BAT_real * T_integration / 3600;
            else Meter_E_BAT_real_discharging = Meter_E_BAT_real_discharging - P_BAT_real * T_integration / 3600;

            if (P_PCC >= 0) P_PCC_Ap = P_PCC_Ap + P_PCC * T_integration / 3600;
            else P_PCC_Am = P_PCC_Am - P_PCC * T_integration / 3600;

            P_PV_meteo_Am = P_PV_meteo_Am - P_PV_meteo * T_integration / 3600;
            P_PV_after_curtail_Am = P_PV_after_curtail_Am - P_PV_after_curtail * T_integration / 3600;
            P_PV_curtail_Am = P_PV_curtail_Am - P_PV_curtail * T_integration / 3600;

            P_CONS_Ap = P_CONS_Ap + P_CONS * T_integration / 3600;

            P_bat_out[S4G_HIL_counter] = P_BAT_real;
            P_PV_curtail_out[S4G_HIL_counter] = P_PV_curtail;
            P_CONS_out[S4G_HIL_counter] = P_CONS;
            SoC_out[S4G_HIL_counter] = SoC;
            //P_PV_meteo_out[S4G_HIL_counter] = P_PV_meteo_in[S4G_HIL_counter];
            P_PV_meteo_out[S4G_HIL_counter] = P_PV_meteo;

            int t_S4G_s_old = t_S4G.Second;
            int t_S4G_ms_old = t_S4G.Millisecond;
            t_S4G = DateTime.Now;

            S4G_HIL_dt = t_S4G.Second * 1000 + t_S4G.Millisecond - t_S4G_s_old * 1000 - t_S4G_ms_old;
            //S4G_HIL_LESSAg_dt = t_S4G.Second * 1000 + t_S4G.Millisecond - t_S4G_1.Second * 1000 - t_S4G_1.Millisecond;
            S4G_HIL_LESSAg_dt = Convert.ToInt16((t_S4G - t_S4G_1).TotalMilliseconds); // time spent in the current LESSAg loop
            S4G_HIL_timer = t_S4G - S4G_start_time; // time passed from the starting point
           
            PROC_log_S4G[S4G_HIL_counter, counter_pos] = (S4G_HIL_counter + sim_start_time).ToString();//????????? poate de lucrat aici
            if (sim_type.ToLower() == "fullday")
            {
                TimeSpan time = TimeSpan.FromSeconds(S4G_HIL_counter * T_integration); // time elapsed, in seconds, after S4G_counter iterations
                PROC_log_S4G[S4G_HIL_counter, datetime_pos] = time.ToString(@"hh\:mm\:ss\:fff");
            }
            else if (sim_type.ToLower() == "realtime")
            {
                DateTime time = DateTime.Now;
                PROC_log_S4G[S4G_HIL_counter, datetime_pos] = time.ToString(@"hh\:mm\:ss\:fff");
            }            
            PROC_log_S4G[S4G_HIL_counter, time_elapsed_pos] = S4G_HIL_dt.ToString("###0.0");
            PROC_log_S4G[S4G_HIL_counter, p_cons_pos] = P_CONS_out[S4G_HIL_counter].ToString("####0.0");
            PROC_log_S4G[S4G_HIL_counter, p_pv_meteo_pos] = P_PV_meteo_out[S4G_HIL_counter].ToString("####0.0");
            PROC_log_S4G[S4G_HIL_counter, p_pv_after_curtail_pos] = P_PV_after_curtail.ToString("####0.0");
            PROC_log_S4G[S4G_HIL_counter, p_bat_real_pos] = P_bat_out[S4G_HIL_counter].ToString("####0.0");
            PROC_log_S4G[S4G_HIL_counter, SoC_pos] = SoC_out[S4G_HIL_counter].ToString("####0.0##");
            PROC_log_S4G[S4G_HIL_counter, p_pcc_pos] = P_PCC.ToString("####0.0");
            PROC_log_S4G[S4G_HIL_counter, p_bat_setpoit_pos] = P_BAT_cd_setpoint.ToString("####0.0");
            PROC_log_S4G[S4G_HIL_counter, 10] = S4G_HIL_LESSAg_dt.ToString("####0.0");
            S4G_HIL_counter = S4G_HIL_counter + 1;
            nr_tot_logs = 86400 / T_integration;

            // Publish new commands in MQTT/JSON format
            if (S4G_var[S4G_var_PROP_P_bat_setp, 0] != "")
            {
                topic1 = "HIL/LESSAg/SMX/PBat";
                payload1 = "[{\"v\":" + S4G_var[S4G_var_PROP_P_bat_setp, 0] + ",\"u\":\"\", \"t\":0, \"n\":\"\"}]";
                S4G_var[S4G_var_PROP_P_bat_setp, 1] = S4G_var[S4G_var_PROP_P_bat_setp, 0];
                S4G_var[S4G_var_PROP_P_bat_setp, 0] = "";
                //if ((topic1 != "") && (payload1 != ""))
                MQTT_Published_Data_S4G();
            }

            //poate fi imbunatatita conditia!!!!!!!!!!!!!!!!
            if ((sim_time == simulation_until_end_of_day) && (S4G_HIL_counter == (nr_tot_logs - sim_start_time)))
            { 
                // timer3_PROC.Stop();
                richTextBox_console1.Text += "LESSAg Simulation completed.";
                generate_report_files();
                //System.Environment.Exit(1);
            }
            else if (S4G_HIL_counter == sim_time/T_integration)
            {
                // timer3_PROC.Stop();
                richTextBox_console1.Text += "LESSAg Simulation completed.";
                generate_report_files();
                //System.Environment.Exit(1);
            }
            // *************************** LESSAg algorithm stop **************************

            // Make load-flow with new dat
        }

        public void generate_report_files()
        {
            string s1 = "";
            DateTime t1 = DateTime.Now;
            //richTextBox_Console.Text += "Time=" + t1.ToLongDateString() + " " + t1.ToLongTimeString() + "\n";

            s1 += "Time=" + t1.ToLongDateString() + " " + t1.ToLongTimeString() + "\n";

            s1 += "*****Configuration****=Conf\n";
            s1 += "LESSAg_project_name=" + LESSAg_project_name + "\n";
            s1 += "PROC_S4G_data_path=" + PROC_S4G_data_path + "\n";
            s1 += "P_CONS_profile_file_name=" + P_CONS_profile_file_name + "\n";
            s1 += "P_CONS_profile_factor=" + Cons_scaling_factor.ToString() + "\n";
            //s1 += "P_CONS_profile_forecast_24h__file_name=" + P_CONS_profile_forecast_24h__file_name + "\n";
            //s1 += "P_CONS_profile_forecast_factor=" + P_CONS_profile_forecast_factor.ToString() + "\n";
            s1 += "P_PV_profile_meteo_file_name=" + P_PV_profile_meteo_file_name + "\n";
            s1 += "P_PV_profile_meteo_factor=" + PV_scaling_factor.ToString() + "\n";
            s1 += "P_PV_profile_meteo_shift=" + P_PV_profile_meteo_shift.ToString() +" h" +"\n";
            //s1 += "P_PV_profile_meteo_foreacst_24h_file_name=" + P_PV_profile_meteo_foreacst_24h_file_name + "\n";
            //s1 += "P_PV_profile_meteo_forecast_24h_factor=" + P_PV_profile_meteo_forecast_24h_factor.ToString() + "\n";

            s1 += "*****Parameters******=param\n";
            s1 += "E_bat_nominal=" + E_bat_nominal.ToString("#0.000") + "\n";
            s1 += "E_bat_min=" + E_bat_min.ToString("#0.000") + "\n";
            s1 += "E_bat_max=" + E_bat_max.ToString("#0.000") + "\n";
            s1 += "P_BAT_max_inverters=" + P_BAT_max_inverters.ToString("#0.000") + "\n";
            s1 += "Battery_charging_efficiency=" + Battery_charging_efficiency.ToString("#0.000") + "\n";
            s1 += "Battery_discharging_efficiency=" + Battery_discharging_efficiency.ToString("#0.000") + "\n";

            s1 += "*****EMS parameters****=EMS\n";
            s1 += "EMS_strategy=" + EMS_strategy + "\n";
            s1 += "P_Cons_SeTpoint=" + P_Cons_SeTpoint.ToString() + "\n";
            //s1 += "\n";

            s1 += "*****Initialisations******=Ini\n";
            s1 += "E_bat_ini=" + (SoC_init*E_bat_nominal).ToString("#0.000") + "\n";
            s1 += "SoC_init=" + SoC_init.ToString("#0.000") + "\n";

            s1 += "*****Test conditions******\n";
            s1 += "Simulation type=" + sim_type + "\n";
            s1 += "simulation time=" + (S4G_HIL_counter * T_integration).ToString() + " s\n";
            s1 += "PCC_injection_allowed=" + PCC_injection_allowed.ToString() + "\n";
            s1 += "P_CONS_mode=" + P_cons_mode.ToString() + "\n";
            s1 += "P_PV_meteo_mode=" + P_PV_meteo_mode.ToString() + "\n";
            s1 += "P_PV_curtail_mode=" + P_PV_curtail_mode.ToString() + "\n";
            s1 += "P_bat_mode=" + P_bat_mode.ToString() + "\n";
            s1 += "SoC_mode=" + SoC_mode.ToString() + "\n";
            s1 += "T_integration=" + T_integration.ToString() + "\n";

            s1 += "*****Results******=Res\n";
            s1 += "P_PCC_Ap=" + P_PCC_Ap.ToString("#0.000") + "\n";
            s1 += "P_PCC_Am=" + P_PCC_Am.ToString("#0.000") + "\n";
            s1 += "P_PV_meteo_Am=" + P_PV_meteo_Am.ToString("#0.000") + "\n";
            s1 += "P_PV_curtail_Am=" + P_PV_curtail_Am.ToString("#0.000") + "\n";
            s1 += "P_PV_after_curtail_Am=" + P_PV_after_curtail_Am.ToString("#0.000") + "\n";
            //s1 += "PV_curt_val=" + PV_curt_val.ToString() + "\n";
            s1 += "P_CONS_Ap=" + P_CONS_Ap.ToString("#0.000") + "\n";
            s1 += "E_bat=" + E_bat.ToString("#0.000") + "\n";
            s1 += "Meter_E_BAT_real_charging=" + Meter_E_BAT_real_charging.ToString("#0.000") + "\n";
            s1 += "Meter_E_BAT_real_discharging=" + Meter_E_BAT_real_discharging.ToString("#0.000") + "\n";

            double d1 = 0;
            d1 = P_PCC_Ap / P_CONS_Ap * 100;
            s1 += "Epcc_plus_on_Econs[%]=" + d1.ToString("#0.000") + "\n";
            d1 = P_PCC_Am / P_CONS_Ap * 100;
            s1 += "Epcc_minus_on_Econs[%]=" + d1.ToString("#0.000") + "\n";
            d1 = -P_PV_meteo_Am / P_CONS_Ap * 100;
            s1 += "K_auto_cons[%]=" + d1.ToString("#0.000") + "\n";

            if (P_PV_meteo_Am != 0) d1 = (P_PV_meteo_Am - P_PV_after_curtail_Am) / P_PV_meteo_Am * 100; else d1 = 0;
            s1 += "PV_curt_val[%]=" + d1.ToString("#0.000") + "\n";

            System.IO.File.WriteAllText(PROC_S4G_data_path + LESSAg_project_name +  "-summary.txt", s1);

            string export = "Counter\tDate_Time(de modificat pentru timp real!!)\ttime_elapsed\tP_cons\tP_PV_meteo\tP_PV_after_curtail\tP_bat\tSoC\tP_PCC\tP_bat_cd_setpoint\tLESSAg_time [ms]\n";
            for (int i = 0; i < nr_tot_logs; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    export += PROC_log_S4G[i, j] + "\t";
                }
                export += "\n";
            }
            System.IO.File.WriteAllText(PROC_S4G_data_path + LESSAg_project_name  + "-Results_Matrix.txt", export);
        }




    }
}