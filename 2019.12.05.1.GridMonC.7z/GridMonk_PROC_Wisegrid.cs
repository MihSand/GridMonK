﻿/*
 * Grid-MonK is an open source softwaer application intended to annalize power grids, esepcially microgrids
 * The basic variant works by invoking the OpenDSS open-source application, with input files prepared by Grid_MonK
 * and export output files read by OpenDSS and used for further calulations and for interracting with a grid specialist.
 * Grid-Monk can be used and modified by anybody, the only condition is to keep these comments unchanged in the upper
 * part of the used or modified application
 * There is no guarrantee given for any functionality or for any
 * influence on the computer(s) running this applications or on other applications which run on the computer(s)
 * Initiator of the Grid-Monk application: Mihai Sanduleac, University Politehnica of Bucharest, Romania
 * This module has been developed for H2020 project WiseGrid
 * Contributors: Mihai Sanduleac, Catalin Chimirel
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft;
using Newtonsoft.Json;
using System.IO;
using System.Diagnostics;

namespace GridMonC
{
    public partial class GridMonk : Form
    {
        public class FcP2DCM
        {
            [JsonProperty("Date")]
            public String date { get; set; }
            
            public class Node
            {
                [JsonProperty("Node_Number")]
                public String nodeNumber { get; set; }
                
                [JsonProperty("Name")]
                public String name { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("U1", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double U1 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("U2", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double U2 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("U3", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double U3 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("P1", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double P1 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("P2", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double P2 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("P3", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double P3 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("Q1", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double Q1 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("Q2", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double Q2 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("Q3", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double Q3 { get; set; }
            }

            public class Line
            {
                [JsonProperty("Line_Number")]
                public String lineNumber { get; set; }
                
                [JsonProperty("Node_Connection")]
                public List<String> nodeConnection { get; set; }

                [JsonProperty("Name")]
                public String name { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("P1", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double P1 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("P2", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double P2 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("P3", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double P3 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("Q1", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double Q1 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("Q2", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double Q2 { get; set; }

                [DefaultValue(0.0)]
                [JsonProperty("Q3", DefaultValueHandling = DefaultValueHandling.Populate)]
                public double Q3 { get; set; }
            }

            [JsonProperty("Nodes")]
            public List<Node> nodes { get; set; }

            [JsonProperty("Lines")]
            public List<Line> lines { get; set; }
        }
        
        void MQTT_Received_Data_Wisegrid(MqttMsgPublishEventArgs e)
        {
            //Input_node_name[0] = "B110-125"; GridMonK_node_number[0] = 0;
            //Input_node_name[1] = "B110-030"; GridMonK_node_number[1] = 13;

            Debug.WriteLine("Received = " + Encoding.UTF8.GetString(e.Message) + " on topic " + e.Topic);
            message_received = Encoding.UTF8.GetString(e.Message);
            if(e.Topic == "pqg-dcm")
            {
                var serializer = new JsonSerializer();
                FcP2DCM res = serializer.Deserialize<FcP2DCM>(new JsonTextReader(new StringReader(Encoding.UTF8.GetString(e.Message))));
                //serializer.Populate(new JsonTextReader(new StringReader(Encoding.UTF8.GetString(e.Message))), res);

                received_date = res.date;

                double P, Q;
                string name = "";

                // Readout of lines data
                int nr_lines = res.lines.Count;
                string line_node1, line_node2;
                int nr_nodeCons = res.lines[0].nodeConnection.Count;
                int line_dest = 0;
                for (int l1=0; l1<nr_lines; l1++)
                {
                    received_lines_q1 = res.lines[1].Q1;
                    line_node1 = res.lines[l1].nodeConnection[0];
                    line_node2 = res.lines[l1].nodeConnection[1];
                    for (int i = 0; i < _GridMonK_Max_Nodes_input_mapping; i++)
                        if ((line_node1 == Input_line_node1_name[i]) && (line_node2 == Input_line_node2_name[i]))
                        {
                            line_dest = GridMonK_line_number[i];
                            lines[line_dest, lines_PROP_P1] = res.lines[l1].P1.ToString();
                            lines[line_dest, lines_PROP_P2] = res.lines[l1].P2.ToString();
                            lines[line_dest, lines_PROP_P3] = res.lines[l1].P3.ToString();
                            lines[line_dest, lines_PROP_Q1] = res.lines[l1].Q1.ToString();
                            lines[line_dest, lines_PROP_Q2] = res.lines[l1].Q2.ToString();
                            lines[line_dest, lines_PROP_Q3] = res.lines[l1].Q3.ToString();
                            P = res.lines[l1].P1 + res.lines[l1].P2 + res.lines[l1].P3;
                            Q = res.lines[l1].Q1 + res.lines[l1].Q2 + res.lines[l1].Q3;
                            lines[line_dest, lines_PROP_P] = P.ToString();
                            lines[line_dest, lines_PROP_Q] = Q.ToString();
                        }
                    //String fstNodeCon = res.lines[0].nodeConnection[0];

                }

                // Readout of nodes data
                int nr_nodes = res.nodes.Count;
                int load_dest = 0;
                for (int n1 = 0; n1 < nr_nodes; n1++)
                {
                    name = res.nodes[n1].name;
                    for (int i = 0; i < _GridMonK_Max_Nodes_input_mapping; i++)
                        if (name == Input_node_name[i])
                        {
                            load_dest = GridMonK_node_number[i];
                            //received_nodes_u3 = res.nodes[0].U3;
                            loads[load_dest, loads_PROP_U1] = res.nodes[n1].U1.ToString();
                            loads[load_dest, loads_PROP_U2] = res.nodes[n1].U2.ToString();
                            loads[load_dest, loads_PROP_U3] = res.nodes[n1].U3.ToString();

                            loads[load_dest, loads_PROP_P1] = res.nodes[n1].P1.ToString();
                            loads[load_dest, loads_PROP_P2] = res.nodes[n1].P2.ToString();
                            loads[load_dest, loads_PROP_P3] = res.nodes[n1].P3.ToString();

                            loads[load_dest, loads_PROP_Q1] = res.nodes[n1].Q1.ToString();
                            loads[load_dest, loads_PROP_Q2] = res.nodes[n1].Q2.ToString();
                            loads[load_dest, loads_PROP_Q3] = res.nodes[n1].Q3.ToString();

                            P = res.nodes[n1].P1 + res.nodes[n1].P2 + res.nodes[n1].P3;
                            Q = res.nodes[n1].Q1 + res.nodes[n1].Q2 + res.nodes[n1].Q3;
                            loads[load_dest, loads_PROP_P] = P.ToString();
                            loads[load_dest, loads_PROP_Q] = Q.ToString();
                        }
                }
            }
            //textBox_remove.Text = message_received;
            // Codul acesta e necesar deoarece ne aflam pe un alt thread de executie decat cel original in care s-au creat elementele de GUI
            /*
            if (this.richTextBox1.InvokeRequired)
            {
                richTextBox1.BeginInvoke((MethodInvoker)delegate ()
                {
                    richTextBox1.AppendText("Topic(" + e.Topic + "): " + Encoding.UTF8.GetString(e.Message) + "\n");
                });
            }
            else
            {
                richTextBox1.AppendText("Topic(" + e.Topic + "): " + Encoding.UTF8.GetString(e.Message) + "\n");
            }
            */
        }

        private void PROC_ini_Wisegrid()
        {
            // read S4G config file "PROC_Wisegrid_config_file.txt"
        }

        private void timer3_PROC_Wisegrid(object sender, EventArgs e)
        {

        }




    }
}