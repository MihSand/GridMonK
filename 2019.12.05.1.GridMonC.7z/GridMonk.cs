﻿/*
 * Grid-MonK is an open source software application intended to annalize power grids, esepcially microgrids
 * The basic variant works by invoking the OpenDSS open-source application, with input files prepared by Grid_MonK
 * and export output files read by OpenDSS and used for further calulations and for interracting with a grid specialist.
 * Grid-Monk can be used and modified by anybody, the only condition is to keep these comments unchanged in the upper
 * part of the used or modified application
 * There is no guarrantee given for any functionality or for any
 * influence on the computer(s) running this applications or on other applications which run on the computer(s)
 * Initiator of the Grid-Monk application: Mihai Sanduleac, University Politehnica of Bucharest, Romania
 * Contributors: 
 *    Special thanks for suggesting improved functionalities: Prof. Mircea Eremia, 
 *    Prof. Associate Lucian Toma, Dr. Catalin Chimirel
 * Basic functionality for a GUI to handle grid objects and to invoke OpenDSS for displaying results and interracting with grid objects
 *   is developed under University Politehnica of Bucharest, Department of Electrical Power Systems, started in September 2018
 * Functionality of next day congestion management dispatch annaysis developed under H2020 project WiseGrid, 
 *      specific developments started in November 2018
 * Functionality related to PMU data simulation and microgrid PMU data sent to a virtual PMU assessment tool is 
 *   developed under H2020 project NRG5, specific developments started in December 2018
 * Functionality related to connection to simulated prosumers developed in the application UnirCon_EMS is  
 *   developed under H2020 project Storage4Grid, specific developments started in December 2018
 * Develpments under free will or for developing different special functionalities needed for research projects are welcome
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Diagnostics;

namespace GridMonC
{
    public partial class GridMonk : Form
    {

        class Poly
        {
            public String name;
            // [ [0, 0], [1, 2], [2, 2] ]
            // [0, 0]
            // [ {"x": 0, "y": 0}, {"x": 1, "y" : 2} ]
            public List<List<double>> lines; // lines[i][0]. lines[i][1]
            public Pen penStyle;
            public Poly(String _name)
            {
                name = _name;
                lines = new List<List<double>>();
                penStyle = new Pen(Color.Black);
            }

            public String mkLines()
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.NullValueHandling = NullValueHandling.Ignore;
                StringBuilder sb = new StringBuilder();
                using (StringWriter sw = new StringWriter(sb))
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, this.lines);
                }
                return sb.ToString();
            }

            public void readLines(String lns)
            {
                try
                {
                    var serializer = new JsonSerializer();
                    serializer.Populate(new JsonTextReader(new StringReader(lns)), this.lines);
                }
                catch { } // da eroare daca nu exisat nici o polilinie
            }

            public String mkString()
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.NullValueHandling = NullValueHandling.Ignore;
                StringBuilder sb = new StringBuilder();
                using (StringWriter sw = new StringWriter(sb))
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, this.lines);
                }
                return "!!polyline=" + name + " !!poly_xy=" + sb.ToString();
            }
        }

        List<Poly> polylines;
        bool drawingPolyline = false;

        string Grid_Monk_Conf = "Grid_Monk_Conf.txt";
        string OpenDSS_Path = "";
        string Grid_Projects_Path = "";
        string GridMonk_Project = "Grid_Ex01";
        string GridMonk_SCADA_information = "SCADA_links.txt";
        string Console_Training_log = "Training_log.txt";
        string Operations_export_JSON = "Operations_export_JSON.txt";
        string OpenDSS_file = "";
        public void read_config_file()
        {
            try
            {
                string[] lines = System.IO.File.ReadAllLines(Grid_Monk_Conf);
                foreach (string line in lines)
                {
                    if (line[0] != '#')
                    {
                        char[] delimiterChars = { '=', '[', ';' };
                        string[] line1 = line.Split(delimiterChars);
                        if (line1[0] == "OpenDSS_Path") OpenDSS_Path = line1[1];
                        if (line1[0] == "Grid_Projects_Path") Grid_Projects_Path = line1[1];
                        if (line1[0] == "GridMonk_Project") GridMonk_Project = line1[1];
                        if (line1[0] == "GUI_Language") GUI_Language = line1[1];

                        // MQTT links can be connected to a specific layout for each project, currently S4G and Wisegrid
                        // The variable "MQTT_Connect" can have at the moment the following possible values: "WiseGrid" or "S4G"
                        if (line1[0] == "MQTT_Connect") MQTT_Connect = line1[1];

                        if (line1[0] == "MQTT_broker_std1") MQTT_broker_std1 = line1[1];
                        if (line1[0] == "MQTT_broker_std1_subscribe_topic") MQTT_broker_std1_subscribe_topic = line1[1];

                        if (line1[0] == "MQTT_broker_std2") MQTT_broker_std2 = line1[1];
                        if (line1[0] == "MQTT_broker_std2_subscribe_topic") MQTT_broker_std2_subscribe_topic = line1[1];

                        if (line1[0] == "GridMonk_SCADA_information") GridMonk_SCADA_information = line1[1];
                    }
                    /*if (line1[0] == "Communication") {
                        if (line1[1] == "COM_port") textBox_com_port.Text = line1[2];
                        if (line1[1] == "COM_info") comboBox_com_info.Text = line1[2];
                        if (line1[1] == "COM_baudrate") comboBox_baudrate.Text = line1[2];
                        if (line1[1] == "Access_level") comboBox_Access_level.Text = line1[2];
                        if (line1[1] == "Password") textBox_password1.Text = line1[2];
                        if (line1[1] == "SLAM_delay1") textBox_SLAM_timeout1.Text = line1[2];
                        if (line1[1] == "SLAM_delay2") textBox_SLAM_timeout2.Text = line1[2];
                    }*/
                }
            }
            catch
            {
                //textBox_path_files.Text = @"C:\";
            }
            OpenDSS_file = GridMonk_Project + ".dss";
            richTextBox_console2.Text = ">> GridMonK config. file:\n" + Grid_Monk_Conf + "\n";
            richTextBox_console2.Text += ">> Path OpenDSS:\n" + OpenDSS_Path +"\n";
            richTextBox_console2.Text += ">> Path Grid:\n" + Grid_Projects_Path + "\n";
            richTextBox_console2.Text += ">> Project:\n" + GridMonk_Project + "\n";

            richTextBox_console2.Text += ">> Grid contexts MAX no: " + historical_values_depth_MAX.ToString() + "\n";
            richTextBox_console2.Text += ">> Grid MAX lines: " + lines_MAX.ToString() + "\n";
            richTextBox_console2.Text += ">> Grid MAX loads: " + loads_MAX.ToString() + "\n";
            richTextBox_console2.Text += ">> Grid MAX generators: " + generators_MAX.ToString() + "\n";
            richTextBox_console2.Text += ">> Grid MAX trafos: " + trafos_MAX.ToString() + "\n";
            richTextBox_console2.Text += ">> Grid MAX nodes: " + nodes_MAX.ToString() + "\n";
            richTextBox_console2.Text += ">> Measurements MAX Smart Meters: " + smart_meters_MAX.ToString() + "\n";

            //button_right_wnd.Image = Image.FromFile("arrow_right1.jpg");
            // Align the image and text on the button.
            //button_right_wnd.ImageAlign = ContentAlignment.MiddleCenter;//.MiddleRight;
            // open source images from https://www.flaticon.com
            button_right_wnd.BackgroundImage = Image.FromFile("arrow_right1.jpg");
            button_right_wnd.BackgroundImageLayout = ImageLayout.Stretch;
            button_left_wnd.BackgroundImage = Image.FromFile("arrow_left1.jpg");
            button_left_wnd.BackgroundImageLayout = ImageLayout.Stretch;
            button_up_wnd.BackgroundImage = Image.FromFile("arrow_up.jpg");
            button_up_wnd.BackgroundImageLayout = ImageLayout.Stretch;
            button_down_wnd.BackgroundImage = Image.FromFile("arrow_down.jpg");
            button_down_wnd.BackgroundImageLayout = ImageLayout.Stretch;
            button_zoom_in.BackgroundImage = Image.FromFile("zoom_in.jpg");
            button_zoom_in.BackgroundImageLayout = ImageLayout.Stretch;
            button_zoom_out.BackgroundImage = Image.FromFile("zoom_out.jpg");
            button_zoom_out.BackgroundImageLayout = ImageLayout.Stretch;
            button_center.BackgroundImage = Image.FromFile("Button_center.jpg");
            button_center.BackgroundImageLayout = ImageLayout.Stretch;

            // initialze PROC modules
            PROC_ini_S4G();
            PROC_ini_Wisegrid();
            PROC_ini_SCADA_FEP();
        }

        int SCADA_nodes_number = 0;
        int SCADA_lines_number = 0;
        public void read_SCADA_file()
        {
            try
            {
                string[] lines = System.IO.File.ReadAllLines(Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + GridMonk_SCADA_information);
                SCADA_nodes_number = 0;
                SCADA_lines_number = 0;
                foreach (string line in lines)
                {
                    if (line[0] != '#')
                    {
                        char[] delimiterChars1 = { '\t', '&', ' ' };
                        string[] line1 = line.Split(delimiterChars1);
                        char[] delimiterChars2 = { '='};
                        string[] line2 = line1[0].Split(delimiterChars2);
                        if ((line2[0] == "object") && (line2[1] == "node"))
                        {
                            char[] delimiterChars3 = { ';' };
                            string[] line3 = line1[1].Split(delimiterChars3);
                            foreach (string line4 in line3)
                            {
                                string[] line5 = line4.Split(delimiterChars2);
                                if (line5[0] == "Input_node_name") Input_node_name[SCADA_nodes_number] = line5[1];
                                if (line5[0] == "GridMonK_node_number") GridMonK_node_number[SCADA_nodes_number] = int.Parse(line5[1]);
                                if (line5[0] == "GridMonK_node_name") GridMonK_node_name[SCADA_nodes_number] = line5[1];

                            }
                            SCADA_nodes_number++;
                        }

                        if ((line2[0] == "object") && (line2[1] == "line"))
                        {
                            char[] delimiterChars3 = { ';' };
                            string[] line3 = line1[1].Split(delimiterChars3);
                            foreach (string line4 in line3)
                            {
                                string[] line5 = line4.Split(delimiterChars2);
                                if (line5[0] == "Input_node_name1") Input_line_node1_name[SCADA_lines_number] = line5[1];
                                if (line5[0] == "Input_node_name2") Input_line_node2_name[SCADA_lines_number] = line5[1];
                                if (line5[0] == "GridMonK_line_number") GridMonK_line_number[SCADA_lines_number] = int.Parse(line5[1]);
                                if (line5[0] == "GridMonK_line_name") GridMonK_line_name[SCADA_lines_number] = line5[1];

                            }
                            SCADA_lines_number++;
                        }
                    }
                    /*if (line1[0] == "Communication") {
                        if (line1[1] == "COM_port") textBox_com_port.Text = line1[2];
                        if (line1[1] == "COM_info") comboBox_com_info.Text = line1[2];
                        if (line1[1] == "COM_baudrate") comboBox_baudrate.Text = line1[2];
                        if (line1[1] == "Access_level") comboBox_Access_level.Text = line1[2];
                        if (line1[1] == "Password") textBox_password1.Text = line1[2];
                        if (line1[1] == "SLAM_delay1") textBox_SLAM_timeout1.Text = line1[2];
                        if (line1[1] == "SLAM_delay2") textBox_SLAM_timeout2.Text = line1[2];
                    }*/
                }
            }
            catch
            {
                //textBox_path_files.Text = @"C:\";
            }
        }

        public GridMonk()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            //this..MaximizeBox();
            polylines = new List<Poly>();

            read_config_file();
            //read_SCADA_file();
            Console_Training_Ini();
            // prepare MQTT connectors
            try
            {
                client1 = new MqttClient(MQTT_broker_std1);
                code = client1.Connect(Guid.NewGuid().ToString());

                client1.MqttMsgPublished += client_MqttMsgPublished;
                client1.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

                MQTT_subscribe("Basic_Topic_client1", 1);
            }
            catch
            {
                Console.WriteLine("Error initialising MQTT Client 1");
            }
            try
            {
                client2 = new MqttClient(MQTT_broker_std1);
                code = client2.Connect(Guid.NewGuid().ToString());

                client2.MqttMsgPublished += client_MqttMsgPublished;
                client2.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

                MQTT_subscribe("#", 2);
                Console.WriteLine("MQTT Client 2 is listening");
            }
            catch
            {
                Console.WriteLine("Error initialising MQTT Client 2");
            }

            for (int i1 = 0; i1 < lines_MAX; i1++) for (int j1 = 0; j1 < lines_prop_MAX; j1++)
                    for (int k1 = 0; k1 < historical_values_depth_MAX; k1++) lines_values_set[i1, j1, k1] = "";
            for (int i1 = 0; i1 < historical_values_depth_MAX; i1++) { Congestions[i1] = ""; Congestions_old[i1] = ""; }
            for (int i1 = 0; i1 < graph_smallgph_MAX; i1++) for (int j1 = 0; j1 < graph_smallgph_prop_MAX; j1++) graph_smallgph[i1, j1] = "";
            for (int i1 = 0; i1 < scenarios_prop_MAX; i1++)
                for (int j1 = 0; j1 < historical_values_depth_MAX; j1++)
                {
                    scenarios[i1, j1] = "";
                }

            gph_phasors_alloc(); // space allocation for gph_phasors
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime t1 = DateTime.Now;
            textBox_DateTime.Text = t1.Year.ToString() + "-" + "-" + t1.Month.ToString() + "-" + t1.Day.ToString()
                + "    " + t1.Hour.ToString() + ":" + t1.Minute.ToString() + ":" + t1.Second.ToString();
            Angle_real_time += (grid_frequency - 50) * 50;
            if(Angle_real_time>360) Angle_real_time += -360; // this angle is for simulating PMU phasors rotation
            //textBox_timeframe_crt.Text = Timeframe_crt_str;

            // read MQTT data 
            MQTT_broker_broker_crt = 1;
            //MQTT_publish("Time", "a" + t1.ToLongDateString(), MQTT_broker_broker_crt);
            MqttClient2_str_in = message_received;
            textBox_remove.Text = message_received;

            Refresh();
        }

        private void timer2_MQTT_pub_Tick(object sender, EventArgs e)
        {
            // data sent as JSON messages
            string s1 = "230", s2 = "0.56", s3 = "50.03", s4 = "1.37";
            // {"SMX1": { "U1": "230", "U1fi"="0.56", "f"="50.03", "rocof"= "1.37" } }
            
            for (int i1 = 0; i1 < PMUs_no; i1++) {
                var jobj = new JObject();
                var smx = new JObject();
                //smx.Add("U1", s1);
                //smx.Add("U1fi", s2);
                //smx.Add("f", s3);
                //smx.Add("rocof", s4);

                smx.Add("Obj", PMUs[i1, PMUs_PROP_obj]);
                smx.Add("Obj_no", PMUs[i1, PMUs_PROP_number]);
                smx.Add("U1", PMUs[i1, PMUs_PROP_U1]);
                smx.Add("U1fi", PMUs[i1, PMUs_PROP_U1fi]);
                smx.Add("U2", PMUs[i1, PMUs_PROP_U2]);
                smx.Add("U2fi", PMUs[i1, PMUs_PROP_U2fi]);
                smx.Add("U3", PMUs[i1, PMUs_PROP_U3]);
                smx.Add("U3fi", PMUs[i1, PMUs_PROP_U3fi]);
                smx.Add("f", s3);
                smx.Add("rocof", s4);
                jobj.Add("PMU", smx);
                string serialized = JsonConvert.SerializeObject(jobj);
                MQTT_publish("PMU"+i1.ToString("00"), serialized, 1);
            }

        }


        int object_dx = 95, object_dxtot = 100, line_dy = 95, line_dytot = 100;
        int object_dx_EV = 48, object_dx_EVtot = 50, object_dy_EV = 78, object_dysmall_EV = 51; // dimensiuni pentru obiecte de tip EV
        int object_x0 = 0, object_y0 = 0;
        int object_x1 = 0, object_y1 = 0; // used for nodes (or other objects) multi-position
        int object_x2 = 0, object_y2 = 0; // used for nodes (or other objects) multi-position

        int obj_number = 0;

        int crtnr = 0;
        private void button_Start_Click(object sender, EventArgs e)
        {
            drawingPolyline = true;
            polylines.Add(new Poly("n" + crtnr.ToString()));
            crtnr++;
        }

        private void button_Stop_Click(object sender, EventArgs e)
        {
            drawingPolyline = false;
        }

        //int x_mouse_crt = 0, y_mouse_crt = 0;
        private int inside_rect(int x1, int y1, int x2, int y2, int px, int py)
        { // if [px, py] are inside the rectangle [x1,y1,x2,y2], it returns 1, else 0
            int res = 0;
            if ((x1 <= px) && (x2 >= px) && (y1 <= py) && (y2 >= py)) res = 1;
            return res;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox_mouse_xy.Text = " (" + e.X.ToString() + ", " + e.Y.ToString() + ")";
            Gph_element_identification(e.X, e.Y);

            if (drawingPolyline)
            {
                int last = polylines.Count() - 1;
                List<List<double>> crt = polylines[last].lines;
                //polylines.Remove(crt);
                List<double> n = new List<double>();
                n.Add(e.X);
                n.Add(e.Y);
                crt.Add(n);
                Refresh();
                //textBox_mouse_xy.Text = crt.Count().ToString();
                textBox_mouse_xy.Text = " (" + e.X.ToString() + ", " + e.Y.ToString() + ")";
            }
        }

        private void button_Next_timeframe_Click(object sender, EventArgs e)
        {

        }

        private void button_Prev_timeframe_Click(object sender, EventArgs e)
        {
            // move to previous timeframe
            //int Timeframe_crt = 1;
            if(Timeframe_crt_str == "Base") Timeframe_crt = 1;
            else Timeframe_crt--;
            if (Timeframe_crt < 1) Timeframe_crt = 1;
            Timeframe_crt_str = Timeframe_crt.ToString();
            textBox_S_max_U_stability.Text = Timeframe_crt_str;

        }

        private void gridSummaryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            calculate_grid_data1();
            richTextBox_console2.Text = calculate_grid_data1_string;
            Refresh();
        }

        private void button_left_wnd_Click(object sender, EventArgs e)
        {
            //   <<==
            X0_shift = X0_shift - Electrical_scheme_zone_delta_X0 / 4;
            if (X0_shift < -Electrical_scheme_zone_delta_X0 * 3 / 4) X0_shift = -Electrical_scheme_zone_delta_X0 * 3 / 4;
        }

        private void button_right_wnd_Click(object sender, EventArgs e)
        {
            //   ==>>
            X0_shift = X0_shift + Electrical_scheme_zone_delta_X0 / 4;
            if (X0_shift > Electrical_scheme_zone_delta_X0 * (3+4+4+4+4) / 4) X0_shift = Electrical_scheme_zone_delta_X0 * (3+4+4+4+4) / 4;
        }

        private void button_up_wnd_Click(object sender, EventArgs e)
        {
            //   ▲ Up
            Y0_shift = Y0_shift - Electrical_scheme_zone_delta_Y0 / 4;
            if (Y0_shift < -Electrical_scheme_zone_delta_Y0 * 3 / 4) Y0_shift = -Electrical_scheme_zone_delta_Y0 * 3 / 4;

        }

        private void button_down_wnd_Click(object sender, EventArgs e)
        {
            //   ▼ Down
            Y0_shift = Y0_shift + Electrical_scheme_zone_delta_Y0 / 4;
            if (Y0_shift > Electrical_scheme_zone_delta_Y0 * 3 / 4) Y0_shift = Electrical_scheme_zone_delta_Y0 * 3 / 4;

        }

        private void button_center_Click(object sender, EventArgs e)
        {
            X0_shift = 0; Y0_shift = 0;
        }

        private void button_zoom_out_Click(object sender, EventArgs e)
        {
            zoom = zoom / 2;
        }

        private void button_zoom_in_Click(object sender, EventArgs e)
        {
            zoom = zoom * 2;

        }
        private void configInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void basicToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Basic reports of the project database, obtained from the GridMonK menu
            string s1 = "";
            for (int n1 = 0; n1 < nodes_no; n1++)
            {
                s1 += "Node=" + n1.ToString("000") +"\t";
                s1 += "Bus=" + nodes[n1, nodes_PROP_bus] + "\t";
                s1 += "Connected_objects=" + nodes[n1, nodes_PROP_list_of_connected_objects] + "\t";
                s1 += "\n";
            }

            GridMonk2OpenDSS_grid_file = Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + "GridMonK_Project_DB_Basic.txt";
            File.WriteAllText(GridMonk2OpenDSS_grid_file, s1);

        }

        private void button_Forecast_Analysis_Click(object sender, EventArgs e)
        {
            if (GridMonK_Congestion_Forecast_mode == 0) GridMonK_Congestion_Forecast_mode = 1; // we swithc to forecast mode
            else GridMonK_Congestion_Forecast_mode = 0;
            if (GridMonK_Congestion_Forecast_mode == 1)
            {
                button_Forecast_Analysis.ForeColor = Color.Red;
            }
            else button_Forecast_Analysis.ForeColor = Color.Black;
        }

        //private void Button_Load_file_Click(object sender, EventArgs e)
        //{

        //}

        private void button_export_JSON_Click(object sender, EventArgs e)
        {
            // Initial developement of this export functionality is for WiseGrid project 
            /* // model of JSON export data
{
"Message_type": "DCM-CkP",
"Congestions_ini": {
"Date": "2018.08.14 10:00",
	"Nodes": [
		{
			"Node_Number": "N308",
			"Name": "N308",
			"U_Limits":  [195.0, 207.0, 230.0, 253.0, 255.0],
			"U1_Assessment": "HIGH",  "U1": 254.4,
			"U2_Assessment": "OK",  "U2": 245.3,
			"U3_Assessment": "HIGH_HIGH", "U3": 255.9
		} ],
	"Lines": [
		{
			"Line_Number": "N011-N127",
			"Node_Connection": ["N011", "N127"],
			"Name": "N011-N127",
			"I_Limits":  [200.0, 300.0],
			"I1_Assessment": "HIGH", "I1": 259.4, "P1": 421.3,  "Q1": -17.2,
			"I2_Assessment": "HIGH", "I2": 259.4, "P2": 421.3, "Q2": -17.2,
			"I3_Assessment": "HIGH", "I3": 259.4, "P3": 421.3, "Q3": -17.2
		} ]
},
"Congestions_final": {
"Date": "2018.08.14 10:00",
	"Nodes": [],
	"Lines": []
}
"Mitigation": {
"Date": "2018.08.14 10:00",

"Loads": [
{
"Node_Number": "1",
"Name": "MV_supply_point_01",
"Type": "Load",
"Q": ["0",  "-140.0"],
"Message": "Parameter Q changed",
"Message_CFM": "Q is requested to increase node voltage"
},
{
"Node_Number": "1",
"Name": "Load_N107",
"Type": "Load",
"P": ["120",  "85.0"],
"Message": "Parameter P changed",
"Message_CFM": "Demand response campain is needed"
},
{
"Node_Number": "N103",
"Name": "Storage_01",
"Type": "Storage",
"P": ["0.0",  "50.0"],
"Message": "Parameter P changed",
"Message_CFM": "P is requested from battery"
},

"Lines": [
{
"Line_Number": "1",
"Node_Connection": ["N201", "N303"],
"Name": "N201-N303",
"Brk1": ["ON", "OFF"],
"Message": "Parameter Brk1 changed",
"Message_CFM": "Line has been disconnected"
},
{
"Line_Number": "7",
"Node_Connection": ["N012", "N021"],
"Name": "N01-N021",
"Brk1": ["ON", "OFF"],
"Message": "Parameter Brk1 changed",
"Message_CFM": "Line has been disconnected"
}
]
}
}
             */
            string s1 = "";
            string s2 = "{\n";
            s2 += "\"Message_type\": \"DCM - CkP\",\n";
            s2 += "\"Congestions_ini\": {\n";
            s2 += "\"Date\": \"2018.08.14 10:00\",\n";
            s2 += "\"GridCongestionsIni_no\": " + GridCongestions_no[0].ToString()+ ",\n";
            s2 += "\"Nodes\": [\n";
            s2 += "],\n";
            s2 += "\"Lines\": [\n";
            s2 += "]\n";
            s2 += "},\n";
            s2 += "\"Congestions_final\": {\n";
            s2 += "\"Date\": \"2018.08.14 10:00\",\n";
            s2 += "\"GridCongestionsFinal_no\": " + GridCongestions_no[1].ToString() + ",\n";
            s2 += "\"Nodes\": [\n";
            s2 += "],\n";
            s2 += "\"Lines\": [\n";
            s2 += "]\n";
            s2 += "},\n";
            s2 += "\"Mitigation\": {\n";

            // construction of the JSON file
            // Make list of "load" operations
            bool first_record = true;
            s2 += "\"Loads\": [\n";
            for (int i1 = 0; i1 < Operations_no; i1++)
            {
                if (Operations[i1, Operations_PROP_object] == "load")
                {
                    if (first_record == false) { s2 += ",\n"; }
                    if (first_record == true) first_record = false;
                    s2 += "{\n";
                    s2 += "\"Node_Number\": \"" + Operations[i1, Operations_PROP_detail3] + "\",\n";
                    s2 += "\"Name\": \"" + Operations[i1, Operations_PROP_name] + "\",\n";
                    s2 += "\"Type\": \"" + Operations[i1, Operations_PROP_detail4] + "\",\n";

                    if (Operations[i1, Operations_PROP_attrib] == "Pn")
                    {
                        s2 += "\"P\": [\"" + Operations[i1, Operations_PROP_value_old] + "\", \"" + Operations[i1, Operations_PROP_value] + "\"],\n";
                        s2 += "\"Message\": \"" + "Parameter P changed" + "\",\n";
                    }
                    if (Operations[i1, Operations_PROP_attrib] == "Qn")
                    {
                        s2 += "\"Q\": [\"" + Operations[i1, Operations_PROP_value_old] + "\", \"" + Operations[i1, Operations_PROP_value] + "\"],\n";
                        s2 += "\"Message\": \"" + "Parameter Q changed" + "\",\n";
                    }
                    if (Operations[i1, Operations_PROP_attrib] == "brk")
                    {
                        s2 += "\"brk\": [\"" + Operations[i1, Operations_PROP_value_old] + "\", \"" + Operations[i1, Operations_PROP_value] + "\"],\n";
                        s2 += "\"Message\": \"" + "Parameter brk changed" + "\",\n";
                    }

                    if (Operations[i1, Operations_PROP_attrib] == "Pn")
                    {
                        if (Operations[i1, Operations_PROP_detail4] == "storage")
                            s2 += "\"Message_CFM\": \"" + "P is requested from battery" + "\"\n";
                        else if (Operations[i1, Operations_PROP_detail4] == "EV")
                            s2 += "\"Message_CFM\": \"" + "P is needed for EV charge" + "\"\n";
                        else
                            s2 += "\"Message_CFM\": \"" + "Demand response campain is needed" + "\"\n";
                    }

                    if (Operations[i1, Operations_PROP_attrib] == "Qn")
                    {
                        s2 += "\"Message_CFM\": \"" + "Q is requested to change node voltage" + "\"\n";
                    }
                    if (Operations[i1, Operations_PROP_attrib] == "brk")
                    {
                        string s3 = "";
                        if (Operations[i1, Operations_PROP_detail4] == "storage") s3 = "Storage";
                        else if (Operations[i1, Operations_PROP_detail4] == "EV") s3 = "EV";
                        if (Operations[i1, Operations_PROP_value] == "off") s2 += "\"Message_CFM\": \"" + s3 + " has been disconnected" + "\"\n";
                        if (Operations[i1, Operations_PROP_value] == "on") s2 += "\"Message_CFM\": \"" + s3 + " has been connected" + "\"\n";
                    }
                    s2 += "}\n";

                }
            }
            s2 += "],\n";
            // Make list of "line" operations
            s2 += "\"Lines\": [\n";
            first_record = true;
            for (int i1 = 0; i1 < Operations_no; i1++)
            {
                if (Operations[i1, Operations_PROP_object] == "line")
                {
                    if (first_record == false) { s2 += ",\n";  }
                    if(first_record == true) first_record = false;
                    s2 += "{\n";
                    s2 += "\"Line_Number\": \"" + Operations[i1, Operations_PROP_detail3] + "\",\n";
                    s2 += "\"Node_Connection\": [\"" + Operations[i1, Operations_PROP_detail1] + "\", \"" + Operations[i1, Operations_PROP_detail2] + "\"],\n";
                    s2 += "\"Name\": \"" + Operations[i1, Operations_PROP_name] + "\",\n";
                    s2 += "\"Type\": \"" + Operations[i1, Operations_PROP_detail4] + "\",\n";
                    if (Operations[i1, Operations_PROP_attrib] == "brk1") { 
                        s2 += "\"Brk1\": [\"" + Operations[i1, Operations_PROP_value_old] + "\", \"" + Operations[i1, Operations_PROP_value] + "\"],\n";
                        s2 += "\"Message\": \"" + "Parameter Brk1 changed" + "\",\n";
                    }
                    if (Operations[i1, Operations_PROP_attrib] == "brk2") { 
                        s2 += "\"Brk2\": [\"" + Operations[i1, Operations_PROP_value_old] + "\", \"" + Operations[i1, Operations_PROP_value] + "\"],\n";
                        s2 += "\"Message\": \"" + "Parameter Brk2 changed" + "\",\n";
                    }
                    if (Operations[i1, Operations_PROP_value] == "off") s2 += "\"Message_CFM\": \"" + "Line has been disconnected" + "\"\n";
                    if (Operations[i1, Operations_PROP_value] == "on") s2 += "\"Message_CFM\": \"" + "Line has been connected" + "\"\n";
                    s2 += "}\n";

                }
            }

            // construction of the text file
            for (int i1=0; i1< Operations_no; i1++)
            {
                s1 += "object=" + Operations[i1, Operations_PROP_object] + "\t";
                s1 += "name=" + Operations[i1, Operations_PROP_name] + "\t";
                s1 += "attrib=" + Operations[i1, Operations_PROP_attrib] + "\t";
                s1 += "value=" + Operations[i1, Operations_PROP_value] + "\t";
                s1 += "date=" + Operations[i1, Operations_PROP_date] + "\t";
                s1 += "time=" + Operations[i1, Operations_PROP_time] + "\t";
                s1 += "TP=" + Operations[i1, Operations_PROP_TimePeriod] + "\t";
                s1 += "TPU=" + Operations[i1, Operations_PROP_TimePeriodUnit] + "\t";
                s1 += "reason=" + Operations[i1, Operations_PROP_reason] + "\t";
                s1 += "\n";

            }

            string Operations_export_file = Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + Operations_export_JSON;
            File.WriteAllText(Operations_export_file, s1);

            s2 += "]\n}\n}";

            string Operations_export_JSON_file = Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + Operations_export_JSON + ".json";
            File.WriteAllText(Operations_export_JSON_file, s2);
        }

        private void button_realtime_data_Click(object sender, EventArgs e)
        {
            if (GridMonK_realtime_data_mode == 0) GridMonK_realtime_data_mode = 1;
            else GridMonK_realtime_data_mode = 0;
            if (GridMonK_realtime_data_mode == 1)
            {
                button_realtime_data.ForeColor = Color.Red;
            }
            else button_realtime_data.ForeColor = Color.Black;

        }

        private void timer3_PROC_Tick(object sender, EventArgs e)
        {
            //timer3_PROC_Wisegrid(sender, e);
            //timer3_PROC_S4G(sender, e);
            {
                timer3_PROC_Wisegrid(sender, e);
                if (activate_S4G_HIL.ToLower() == "yes") //validation check for the HIL module
                {
                    timer3_PROC_S4G(sender, e);
                }
            }
        }

        private void reloadConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _GridMonK_GUI_refresh = "Stop";
            read_config_file();
            Console_Training_Ini();
            Load_project();
            _GridMonK_GUI_refresh = "Refresh";

        }

        private void button_remove_Click(object sender, EventArgs e)
        {
            String name = textBox_remove.Text;
            //polylines.Remove(polylines.Find(x => x.name == name));
            textBox_mouse_xy.Text = polylines.LastIndexOf(polylines.Find(x => x.name == name)).ToString();
            richTextBox_console2.Text += polylines.Find(x => x.name == name).mkString() + "\n";
            Refresh();
        }

        private void button_Compute_Click(object sender, EventArgs e)
        {
            DateTime t1 = DateTime.Now;
            string st1 = ">> Grid compute\n";
            int t1s = t1.Second, t1ms = t1.Millisecond;
            st1 += "T(ini):" + t1.Year.ToString() + "." + t1.Month.ToString("00") + "." + t1.Day.ToString("00")
                + " " + t1.Hour.ToString("00") + ":" + t1.Minute.ToString("00") + ":" + t1.Second.ToString("00")
                 + "." + t1.Millisecond.ToString("000") + "\n";
            string richTextBox_console_answers_str = st1;

            richTextBox_console_answers_str += ">> Generate output (";
            generate_output_dss("multi_LP_RMB_and_24h", "Forecast"); // se salveaza statusul curent al retelei

            t1 = DateTime.Now;
            int t2s = t1.Second, t2ms = t1.Millisecond; // dupa generate_output_dss()
            int dt2_msec = t2s * 1000 + t2ms - t1s * 1000 - t1ms;
            if (dt2_msec < 0) dt2_msec = dt2_msec + 60000;
            richTextBox_console_answers_str += dt2_msec.ToString() + " ms)\n";

            richTextBox_console_answers_str += ">> Invoke OpenDSS (";
            OpenDSS_invoke("multi_LP_RMB_and_24h"); // se lanseaza OpenDSS
            t1 = DateTime.Now;
            int t3s = t1.Second, t3ms = t1.Millisecond;
            int dt3_msec = t3s * 1000 + t3ms - t2s * 1000 - t2ms;
            if (dt3_msec < 0) dt3_msec = dt3_msec + 60000;
            richTextBox_console_answers_str += dt3_msec.ToString() + " ms)\n";

            richTextBox_console_answers_str += ">> Process results (";
            read_OpenDSS_results("multi_LP_RMB_and_24h"); // se citesc rezultatele din fiserele de iesire ale OpenDSS
            t1 = DateTime.Now;
            int t4s = t1.Second, t4ms = t1.Millisecond;
            int dt4_msec = t4s * 1000 + t4ms - t3s * 1000 - t3ms;
            if (dt4_msec < 0) dt4_msec = dt4_msec + 60000;
            richTextBox_console_answers_str += dt4_msec.ToString() + " ms)\n";

            Grid_is_calculated = 1; // some further functions can work only if the grid is calculated (Compute is requested)

            assess_nodes_properties(); // in urma valorilor rezultat, asociate la obiecte, se fac calcule legate de noduri
            add_nodes_properties_from_paramaterisation_nodes_metadata(); // proprietati de noduri din parametrzarea initiala; nu se cheama aceasta component ataunci cand se parcurg cele 24 ore

            calculate_values_from_results(); // in urma valorilor rezultat, asociate la obiecte, se fac calcule legate de noduri
            Timeframe_crt = -1;

            DateTime t2;
            t2 = DateTime.Now;
            richTextBox_console_answers_str += "T(end):" + t2.Year.ToString() + "." + t2.Month.ToString("00") + "." + t2.Day.ToString("00")
                            + " " + t2.Hour.ToString("00") + ":" + t2.Minute.ToString("00") + ":" + t2.Second.ToString("00")
                            +"." + t2.Millisecond.ToString("000") + "\n";
            int dt_msec = t2.Second * 1000 + t2.Millisecond - t1s * 1000 - t1ms;
            if (dt_msec < 0) dt_msec = dt_msec + 60000;
            //richTextBox_console_answers_str = "Command not accepted";
            richTextBox_console_answers_str += "Total time (msec)= " + dt_msec.ToString();
            richTextBox_console_answers.Text = richTextBox_console_answers_str;

            // reseteaza continutul graficelor
            for (int i1 = 0; i1 < SimpleGph_channels_MAX; i1++)
                for (int j1 = 0; j1 < SimpleGph_channels_depth_MAX; j1++)
                {
                    SimpleGph_channels1[i1, j1] = 0;
                    SimpleGph_channels2[i1, j1] = 0;
                }
            channel_free1 = 0;
            channel_free2 = 0;
            for (int i1 = 0; i1 < SimpleGph_channels_MAX; i1++) channel_name[i1] = "";

            typeof_24hours_set = "forecast";

            if (GridMonK_Congestion_Forecast_mode == 1)
                for (int interval = 0; interval < 24; interval++)
                {
                    generate_output_dss("GridMonk_Project_" + interval.ToString("00"), "Snapshoot");  // producere fisier de iesire compatibil dss.
                }

            Refresh(); // se redeseneaza GUI
        }

        /// Invoke OpenDSS
        void OpenDSS_invoke(string OpenDSS_file)
        {
            // STDERR_OpenDSS.Txt
            System.IO.File.Delete(Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + "STDERR_OpenDSS.Txt");

            // Delete previous results
            var dir = new DirectoryInfo(Grid_Projects_Path + @"/" + GridMonk_Project + @"/");
            foreach (var file in dir.EnumerateFiles("*.csv"))
            {
                file.Delete();
            }
            //System.IO.File.Delete(Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + "*.csv");

            //GridMonk2OpenDSS_grid_file = Grid_Projects_Path + @"\" + GridMonk_Project + @"\" + "output1.dss";
            GridMonk2OpenDSS_grid_file = Grid_Projects_Path + @"/" + GridMonk_Project + @"/" + OpenDSS_file + ".dss";

            // se ruleaza OpenDSS
            ProcessStartInfo startInfo = new ProcessStartInfo(); // E:\App\VStudio\GridMonK\GM_Projects
            startInfo.FileName = OpenDSS_Path+ @"/OpenDSS.exe";
            if(checkBox_file_dss.Checked==true) // se foloseste fisierul initial
                startInfo.Arguments = @"E:/App/VStudio/GridMonK/PowerGrid/Grid_test_01_Monc.dss /nogui";
            else // se foloseste fisierul ce descrie starea curenta a retelei, rezultaet in urma interactiunii GUI
                startInfo.Arguments = GridMonk2OpenDSS_grid_file + " /nogui";
            Process prc = Process.Start(startInfo);
            prc.WaitForExit(5000);
            
            if(!prc.HasExited)
            {
                // return -1; sau altceva => s-a blocat
            }
            System.Threading.Thread.Sleep(100); // se asteapta 100 milisecunde;

            //System.Threading.Thread.Sleep(1500); // se asteapta 1.5 secunde; timpul ar putea sa creasca sau se va implementa o alta varianta 

        }

        void calculate_values_from_results()
        {
            // se calculeaza marimi ce se pot deduce din cele citite 
            double P3f = 0;
            double Q3f = 0;
            double S3f = 0;

            if (Grid_is_calculated == 0) return;

            // loads
            for (int i1 = 0; i1 < loads_no; i1++)
            {
                if ((loads[i1, loads_PROP_P1] != "") && (loads[i1, loads_PROP_P2] != "") && (loads[i1, loads_PROP_P3] != ""))
                {
                    P3f = double.Parse(loads[i1, loads_PROP_P1]) + double.Parse(loads[i1, loads_PROP_P2]) + +double.Parse(loads[i1, loads_PROP_P3]);
                    loads[i1, loads_PROP_P] = P3f.ToString("#####0.000");
                }
                if ((loads[i1, loads_PROP_Q1] != "") && (loads[i1, loads_PROP_Q2] != "") && (loads[i1, loads_PROP_Q3] != ""))
                {
                    Q3f = double.Parse(loads[i1, loads_PROP_Q1]) + double.Parse(loads[i1, loads_PROP_Q2]) + +double.Parse(loads[i1, loads_PROP_Q3]);
                    loads[i1, loads_PROP_Q] = Q3f.ToString("#####0.000");
                }

            }
            for (int i1 = 0; i1 < loads_MAX; i1++)
                for (int j1 = LPs_scenarios_multi_LF_start + 1; j1 < historical_values_depth_MAX- LPs_scenarios_multi_LF_start - 1; j1++)
                {
                    if ((loads_values_set[i1, loads_PROP_P1, j1] != "") && (loads_values_set[i1, loads_PROP_P2, j1] != "") && (loads_values_set[i1, loads_PROP_P3, j1] != ""))
                    {
                        P3f = double.Parse(loads_values_set[i1, loads_PROP_P1, j1]) + double.Parse(loads_values_set[i1, loads_PROP_P2, j1]) + double.Parse(loads_values_set[i1, loads_PROP_P3, j1]);
                        loads_values_set[i1, loads_PROP_P, j1] = P3f.ToString("#####0.0");
                    }
                    if ((loads_values_set[i1, loads_PROP_Q1, j1] != "") && (loads_values_set[i1, loads_PROP_Q2, j1] != "") && (loads_values_set[i1, loads_PROP_Q3, j1] != ""))
                    {
                        Q3f = double.Parse(loads_values_set[i1, loads_PROP_Q1, j1]) + double.Parse(loads_values_set[i1, loads_PROP_Q2, j1]) + double.Parse(loads_values_set[i1, loads_PROP_Q3, j1]);
                        loads_values_set[i1, loads_PROP_Q, j1] = Q3f.ToString("#####0.0");
                    }
                }

            // lines
            for (int i1 = 0; i1 < lines_no; i1++)
            {
                if ((lines[i1, lines_PROP_P1] != "") && (lines[i1, lines_PROP_P2] != "") && (lines[i1, lines_PROP_P3] != ""))
                {
                    P3f = double.Parse(lines[i1, lines_PROP_P1]) + double.Parse(lines[i1, lines_PROP_P2]) + +double.Parse(lines[i1, lines_PROP_P3]);
                    lines[i1, lines_PROP_P] = P3f.ToString("#####0.0");
                }
                if ((lines[i1, lines_PROP_Q1] != "") && (lines[i1, lines_PROP_Q2] != "") && (lines[i1, lines_PROP_Q3] != ""))
                {
                    Q3f = double.Parse(lines[i1, lines_PROP_Q1]) + double.Parse(lines[i1, lines_PROP_Q2]) + +double.Parse(lines[i1, lines_PROP_Q3]);
                    lines[i1, lines_PROP_Q] = Q3f.ToString("#####0.0");
                }
                if ((lines[i1, lines_PROP_P] != "") && (lines[i1, lines_PROP_Q] != ""))
                {
                    S3f = Math.Sqrt(P3f*P3f + Q3f*Q3f);
                    lines[i1, lines_PROP_S] = S3f.ToString("#####0.0");
                }

                if ((lines[i1, lines_PROP_P1_t2] != "") && (lines[i1, lines_PROP_P2_t2] != "") && (lines[i1, lines_PROP_P3_t2] != ""))
                {
                    P3f = double.Parse(lines[i1, lines_PROP_P1_t2]) + double.Parse(lines[i1, lines_PROP_P2_t2]) + +double.Parse(lines[i1, lines_PROP_P3_t2]);
                    lines[i1, lines_PROP_P_t2] = P3f.ToString("#####0.0");
                }
                if ((lines[i1, lines_PROP_Q1_t2] != "") && (lines[i1, lines_PROP_Q2_t2] != "") && (lines[i1, lines_PROP_Q3_t2] != ""))
                {
                    Q3f = double.Parse(lines[i1, lines_PROP_Q1_t2]) + double.Parse(lines[i1, lines_PROP_Q2_t2]) + +double.Parse(lines[i1, lines_PROP_Q3_t2]);
                    lines[i1, lines_PROP_Q_t2] = Q3f.ToString("#####0.0");
                }
                if ((lines[i1, lines_PROP_P_t2] != "") && (lines[i1, lines_PROP_Q_t2] != ""))
                {
                    S3f = Math.Sqrt(P3f * P3f + Q3f * Q3f);
                    lines[i1, lines_PROP_S_t2] = S3f.ToString("#####0.0");
                }

                int found_linecode = -1;
                for (int j1 = 0; j1 < linecodes_no; j1++)
                {
                    if (linecodes[j1, linecodes_PROP_name] == lines[i1, lines_PROP_linecode])
                    {
                        found_linecode = j1; j1 = linecodes_no;
                    }
                }
                if (found_linecode != -1) { 
                    double R1 = 0;
                    if (linecodes[found_linecode, linecodes_PROP_R1] != "")
                    R1 = double.Parse(linecodes[found_linecode, linecodes_PROP_R1]) * double.Parse(lines[i1, lines_PROP_length]);
                    lines[i1, lines_PROP_R1] = R1.ToString("###0.000");
                    double X1 = 0;
                    if (linecodes[found_linecode, linecodes_PROP_X1] != "")
                    X1 = double.Parse(linecodes[found_linecode, linecodes_PROP_X1]) * double.Parse(lines[i1, lines_PROP_length]);
                    lines[i1, lines_PROP_X1] = X1.ToString("###0.000");
                    //double Imax = 0;
                    if (linecodes[found_linecode, linecodes_PROP_Imax] != "")
                        lines[i1, lines_PROP_Imax] = linecodes[found_linecode, linecodes_PROP_Imax];
                    //double Umax = 0;
                    if (linecodes[found_linecode, linecodes_PROP_Umax] != "")
                        lines[i1, lines_PROP_Umax] = linecodes[found_linecode, linecodes_PROP_Umax];
                }
            }
            for (int i1 = 0; i1 < lines_MAX; i1++)
                for (int j1 = LPs_scenarios_multi_LF_start + 1; j1 < historical_values_depth_MAX - LPs_scenarios_multi_LF_start - 1; j1++)
                {
                    if ((lines_values_set[i1, lines_PROP_P1, j1] !="") && (lines_values_set[i1, lines_PROP_P2, j1] != "") && (lines_values_set[i1, lines_PROP_P3, j1] != ""))
                    {
                        P3f = double.Parse(lines_values_set[i1, lines_PROP_P1, j1]) + double.Parse(lines_values_set[i1, lines_PROP_P2, j1]) + +double.Parse(lines_values_set[i1, lines_PROP_P3, j1]);
                        lines_values_set[i1, lines_PROP_P, j1] = P3f.ToString("#####0.0");
                    }
                    if ((lines_values_set[i1, lines_PROP_P1_t2, j1] != "") && (lines_values_set[i1, lines_PROP_P2_t2, j1] != "") && (lines_values_set[i1, lines_PROP_P3_t2, j1] != ""))
                    {
                        P3f = double.Parse(lines_values_set[i1, lines_PROP_P1_t2, j1]) + double.Parse(lines_values_set[i1, lines_PROP_P2_t2, j1]) + +double.Parse(lines_values_set[i1, lines_PROP_P3_t2, j1]);
                        lines_values_set[i1, lines_PROP_P_t2, j1] = P3f.ToString("#####0.0");
                    }
                    if ((lines_values_set[i1, lines_PROP_Q1, j1] != "") && (lines_values_set[i1, lines_PROP_Q2, j1] != "") && (lines_values_set[i1, lines_PROP_Q3, j1] != ""))
                    {
                        Q3f = double.Parse(lines_values_set[i1, lines_PROP_Q1, j1]) + double.Parse(lines_values_set[i1, lines_PROP_Q2, j1]) + +double.Parse(lines_values_set[i1, lines_PROP_Q3, j1]);
                        lines_values_set[i1, lines_PROP_Q, j1] = Q3f.ToString("#####0.0");
                    }
                    if ((lines_values_set[i1, lines_PROP_Q1_t2, j1] != "") && (lines_values_set[i1, lines_PROP_Q2_t2, j1] != "") && (lines_values_set[i1, lines_PROP_Q3_t2, j1] != ""))
                    {
                        Q3f = double.Parse(lines_values_set[i1, lines_PROP_Q1_t2, j1]) + double.Parse(lines_values_set[i1, lines_PROP_Q2_t2, j1]) + +double.Parse(lines_values_set[i1, lines_PROP_Q3_t2, j1]);
                        lines_values_set[i1, lines_PROP_Q_t2, j1] = Q3f.ToString("#####0.0");
                    }
                    if ((lines_values_set[i1, lines_PROP_P, j1] != "") && (lines_values_set[i1, lines_PROP_Q, j1] != ""))
                    {
                        S3f = double.Parse(lines_values_set[i1, lines_PROP_P, j1])* double.Parse(lines_values_set[i1, lines_PROP_P, j1])
                            + double.Parse(lines_values_set[i1, lines_PROP_Q, j1])*double.Parse(lines_values_set[i1, lines_PROP_Q, j1]);
                        lines_values_set[i1, lines_PROP_S, j1] = Q3f.ToString("#####0.0");
                    }
                }

            // generators
            for (int i1 = 0; i1 < generators_no; i1++)
            {
                if ((generators[i1, generators_PROP_P1] != "") && (generators[i1, generators_PROP_P2] != "") && (generators[i1, generators_PROP_P3] != ""))
                {
                    P3f = double.Parse(generators[i1, generators_PROP_P1]) + double.Parse(generators[i1, generators_PROP_P2]) + +double.Parse(generators[i1, generators_PROP_P3]);
                    generators[i1, generators_PROP_P] = P3f.ToString("#####0.0");
                }
                if ((generators[i1, generators_PROP_Q1] != "") && (generators[i1, generators_PROP_Q2] != "") && (generators[i1, generators_PROP_Q3] != ""))
                {
                    Q3f = double.Parse(generators[i1, generators_PROP_Q1]) + double.Parse(generators[i1, generators_PROP_Q2]) + +double.Parse(generators[i1, generators_PROP_Q3]);
                    generators[i1, generators_PROP_Q] = Q3f.ToString("#####0.0");
                }
                if ((generators[i1, generators_PROP_P] != "") && (generators[i1, generators_PROP_Q] != ""))
                {
                    S3f = Math.Sqrt(P3f * P3f + Q3f * Q3f);
                    generators[i1, generators_PROP_S] = S3f.ToString("#####0.0");
                }
            }
            for (int i1 = 0; i1 < generators_MAX; i1++)
                for (int j1 = LPs_scenarios_multi_LF_start + 1; j1 < historical_values_depth_MAX - LPs_scenarios_multi_LF_start - 1; j1++)
                {
                    if ((generators_values_set[i1, generators_PROP_P1, j1] != "") && (generators_values_set[i1, generators_PROP_P2, j1] != "") && (generators_values_set[i1, generators_PROP_P3, j1] != ""))
                    {
                        P3f = double.Parse(generators_values_set[i1, generators_PROP_P1, j1]) + double.Parse(generators_values_set[i1, generators_PROP_P2, j1]) + +double.Parse(generators_values_set[i1, generators_PROP_P3, j1]);
                        generators_values_set[i1, generators_PROP_P, j1] = P3f.ToString("#####0.0");
                    }
                    if ((generators_values_set[i1, generators_PROP_Q1, j1] != "") && (generators_values_set[i1, generators_PROP_Q2, j1] != "") && (generators_values_set[i1, generators_PROP_Q3, j1] != ""))
                    {
                        Q3f = double.Parse(generators_values_set[i1, generators_PROP_Q1, j1]) + double.Parse(generators_values_set[i1, generators_PROP_Q2, j1]) + +double.Parse(generators_values_set[i1, generators_PROP_Q3, j1]);
                        generators_values_set[i1, generators_PROP_Q, j1] = Q3f.ToString("#####0.0");
                    }
                }

            // trafos
            for (int i1 = 0; i1 < trafos_no; i1++)
            {
                if ((trafos[i1, trafos_PROP_P1] != "") && (trafos[i1, trafos_PROP_P2] != "") && (trafos[i1, trafos_PROP_P3] != ""))
                {
                    P3f = double.Parse(trafos[i1, trafos_PROP_P1]) + double.Parse(trafos[i1, trafos_PROP_P2]) + +double.Parse(trafos[i1, trafos_PROP_P3]);
                    trafos[i1, trafos_PROP_P] = P3f.ToString("#####0.0");
                }
                if ((trafos[i1, trafos_PROP_Q1] != "") && (trafos[i1, trafos_PROP_Q2] != "") && (trafos[i1, trafos_PROP_Q3] != ""))
                {
                    Q3f = double.Parse(trafos[i1, trafos_PROP_Q1]) + double.Parse(trafos[i1, trafos_PROP_Q2]) + +double.Parse(trafos[i1, trafos_PROP_Q3]);
                    trafos[i1, trafos_PROP_Q] = Q3f.ToString("#####0.0");
                }
                if ((trafos[i1, trafos_PROP_P] != "") && (trafos[i1, trafos_PROP_Q] != ""))
                {
                    S3f = Math.Sqrt(P3f * P3f + Q3f * Q3f);
                    trafos[i1, trafos_PROP_S] = S3f.ToString("#####0.0");
                }
            }
            for (int i1 = 0; i1 < trafos_MAX; i1++)
                for (int j1 = LPs_scenarios_multi_LF_start + 1; j1 < historical_values_depth_MAX - LPs_scenarios_multi_LF_start - 1; j1++)
                {
                    if ((trafos_values_set[i1, trafos_PROP_P1, j1] != "") && (trafos_values_set[i1, trafos_PROP_P2, j1] != "") && (trafos_values_set[i1, trafos_PROP_P3, j1] != ""))
                    {
                        P3f = double.Parse(trafos_values_set[i1, trafos_PROP_P1, j1]) + double.Parse(trafos_values_set[i1, trafos_PROP_P2, j1]) + +double.Parse(trafos_values_set[i1, trafos_PROP_P3, j1]);
                        trafos_values_set[i1, trafos_PROP_P, j1] = P3f.ToString("#####0.0");
                    }
                    if ((trafos_values_set[i1, trafos_PROP_Q1, j1] != "") && (trafos_values_set[i1, trafos_PROP_Q2, j1] != "") && (trafos_values_set[i1, trafos_PROP_Q3, j1] != ""))
                    {
                        Q3f = double.Parse(trafos_values_set[i1, trafos_PROP_Q1, j1]) + double.Parse(trafos_values_set[i1, trafos_PROP_Q2, j1]) + +double.Parse(trafos_values_set[i1, trafos_PROP_Q3, j1]);
                        trafos_values_set[i1, trafos_PROP_Q, j1] = Q3f.ToString("#####0.0");
                    }
                    if ((trafos_values_set[i1, trafos_PROP_P, j1] != "") && (trafos_values_set[i1, trafos_PROP_Q, j1] != ""))
                    {
                        S3f = double.Parse(trafos_values_set[i1, trafos_PROP_P, j1]) * double.Parse(trafos_values_set[i1, trafos_PROP_P, j1])
                            + double.Parse(trafos_values_set[i1, trafos_PROP_Q, j1]) * double.Parse(trafos_values_set[i1, trafos_PROP_Q, j1]);
                        trafos_values_set[i1, trafos_PROP_S, j1] = Q3f.ToString("#####0.0");
                    }
                }

            // calculate synthetic data (lossess, totalk powers etc.) for each scenario
            calculate_grid_data_scenarios_array();
        }

        void assess_nodes_properties()
        {
            //  
            // se aloca tensiuni la noduri, prin citirea tensiunii unui "load", "generator" sau "line"  conectat la acel nod
            // (in ac. ordine si prioritate de alocare)
            for (int n1 = 0; n1 < nodes_no; n1++)
            {
                int object_no = -1;
                if(nodes[n1, nodes_PROP_U_source_object] == "load") { 
                    if(nodes[n1, nodes_PROP_U_source_object_number] != "") {
                        object_no = int.Parse(nodes[n1, nodes_PROP_U_source_object_number]);
                        nodes[n1, nodes_PROP_U1] = loads[object_no, loads_PROP_U1];
                        nodes[n1, nodes_PROP_U2] = loads[object_no, loads_PROP_U2];
                        nodes[n1, nodes_PROP_U3] = loads[object_no, loads_PROP_U3];
                        nodes[n1, nodes_PROP_U4] = loads[object_no, loads_PROP_U4];

                        nodes[n1, nodes_PROP_U1fi] = loads[object_no, loads_PROP_U1fi];
                        nodes[n1, nodes_PROP_U2fi] = loads[object_no, loads_PROP_U2fi];
                        nodes[n1, nodes_PROP_U3fi] = loads[object_no, loads_PROP_U3fi];
                        nodes[n1, nodes_PROP_U4fi] = loads[object_no, loads_PROP_U4fi];

                        nodes[n1, nodes_PROP_voltage] = loads[object_no, loads_PROP_voltage];
                        if(loads[object_no, loads_PROP_brk]=="on")
                        nodes[n1, nodes_PROP_U_source_object_avail_U_meas] = "1"; 
                        else nodes[n1, nodes_PROP_U_source_object_avail_U_meas] = "0";
                    }
                }
                else if (nodes[n1, nodes_PROP_U_source_object] == "generator") { 
                    if (nodes[n1, nodes_PROP_U_source_object_number] != "")
                    {
                        object_no = int.Parse(nodes[n1, nodes_PROP_U_source_object_number]);
                        nodes[n1, nodes_PROP_U1] = generators[object_no, generators_PROP_U1];
                        nodes[n1, nodes_PROP_U2] = generators[object_no, generators_PROP_U2];
                        nodes[n1, nodes_PROP_U3] = generators[object_no, generators_PROP_U3];
                        nodes[n1, nodes_PROP_U4] = generators[object_no, generators_PROP_U4];

                        nodes[n1, nodes_PROP_U1fi] = generators[object_no, generators_PROP_U1fi];
                        nodes[n1, nodes_PROP_U2fi] = generators[object_no, generators_PROP_U2fi];
                        nodes[n1, nodes_PROP_U3fi] = generators[object_no, generators_PROP_U3fi];
                        nodes[n1, nodes_PROP_U4fi] = generators[object_no, generators_PROP_U4fi];

                        nodes[n1, nodes_PROP_voltage] = generators[object_no, loads_PROP_voltage];
                        if (generators[object_no, loads_PROP_brk] == "on")
                            nodes[n1, nodes_PROP_U_source_object_avail_U_meas] = "1";
                        else nodes[n1, nodes_PROP_U_source_object_avail_U_meas] = "0";
                    }
                }
                else if (nodes[n1, nodes_PROP_U_source_object] == "line")
                {
                    if (nodes[n1, nodes_PROP_U_source_object_number] != "")
                    {
                        object_no = int.Parse(nodes[n1, nodes_PROP_U_source_object_number]);
                        nodes[n1, nodes_PROP_U1] = lines[object_no, lines_PROP_U1];
                        nodes[n1, nodes_PROP_U2] = lines[object_no, lines_PROP_U2];
                        nodes[n1, nodes_PROP_U3] = lines[object_no, lines_PROP_U3];
                        //nodes[n1, nodes_PROP_U4] = lines[object_no, lines_PROP_U4];

                        nodes[n1, nodes_PROP_U1fi] = lines[object_no, lines_PROP_U1fi];
                        nodes[n1, nodes_PROP_U2fi] = lines[object_no, lines_PROP_U2fi];
                        nodes[n1, nodes_PROP_U3fi] = lines[object_no, lines_PROP_U3fi];
                        //nodes[n1, nodes_PROP_U4fi] = lines[object_no, lines_PROP_U4fi];

                        nodes[n1, nodes_PROP_voltage] = generators[object_no, loads_PROP_voltage];
                        if (generators[object_no, loads_PROP_brk] == "on")
                            nodes[n1, nodes_PROP_U_source_object_avail_U_meas] = "1";
                        else nodes[n1, nodes_PROP_U_source_object_avail_U_meas] = "0";
                    }
                }
            }
/*            for (int n1 = 0; n1 < nodes_no; n1++)
            {
                // se aloca proprietati ndourile, rezultate din declaraii de tip nodes_metadata
                for (int m1 = 0; m1 < nodes_metadata_no; m1++)
                {
                    if (nodes_metadata[m1, nodes_metadata_PROP_bus] == nodes[n1, nodes_PROP_bus]) {
                        nodes[n1, nodes_PROP_name] = nodes_metadata[m1, nodes_metadata_PROP_name];
                        nodes[n1, nodes_PROP_x0] = nodes_metadata[m1, nodes_metadata_PROP_x0];
                        nodes[n1, nodes_PROP_y0] = nodes_metadata[m1, nodes_metadata_PROP_y0];
                        nodes[n1, nodes_PROP_arrow] = nodes_metadata[m1, nodes_metadata_PROP_arrow];
                        nodes[n1, nodes_PROP_bus_name] = nodes_metadata[m1, nodes_metadata_PROP_bus_name];
                        nodes[n1, nodes_PROP_draw_U1] = nodes_metadata[m1, nodes_metadata_PROP_draw_U1];
                        nodes[n1, nodes_PROP_draw_U1fi] = nodes_metadata[m1, nodes_metadata_PROP_draw_U1fi];
                    }
                }
            }
            */
        }

        void add_nodes_properties_from_paramaterisation_nodes_metadata()
        {
            //  Add nodes properties from nodes metadata associated with these nodes
            for (int n1 = 0; n1 < nodes_no; n1++)
            {
                // se aloca proprietati ndourile, rezultate din declaraii de tip nodes_metadata
                for (int m1 = 0; m1 < nodes_metadata_no; m1++)
                {
                    if (nodes_metadata[m1, nodes_metadata_PROP_bus] == nodes[n1, nodes_PROP_bus])
                    {
                        nodes[n1, nodes_PROP_name] = nodes_metadata[m1, nodes_metadata_PROP_name];
                        nodes[n1, nodes_PROP_x0] = nodes_metadata[m1, nodes_metadata_PROP_x0];
                        nodes[n1, nodes_PROP_y0] = nodes_metadata[m1, nodes_metadata_PROP_y0];
                        nodes[n1, nodes_PROP_x1] = nodes_metadata[m1, nodes_metadata_PROP_x1];
                        nodes[n1, nodes_PROP_y1] = nodes_metadata[m1, nodes_metadata_PROP_y1];
                        nodes[n1, nodes_PROP_con1from] = nodes_metadata[m1, nodes_metadata_PROP_con1from];
                        nodes[n1, nodes_PROP_x2] = nodes_metadata[m1, nodes_metadata_PROP_x2];
                        nodes[n1, nodes_PROP_y2] = nodes_metadata[m1, nodes_metadata_PROP_y2];
                        nodes[n1, nodes_PROP_con2from] = nodes_metadata[m1, nodes_metadata_PROP_con2from];
                        nodes[n1, nodes_PROP_arrow] = nodes_metadata[m1, nodes_metadata_PROP_arrow];
                        nodes[n1, nodes_PROP_bus_name] = nodes_metadata[m1, nodes_metadata_PROP_bus_name];
                        nodes[n1, nodes_PROP_bus_name_x] = nodes_metadata[m1, nodes_metadata_PROP_bus_name_x];
                        nodes[n1, nodes_PROP_bus_name_y] = nodes_metadata[m1, nodes_metadata_PROP_bus_name_y];
                        nodes[n1, nodes_PROP_draw_U1] = nodes_metadata[m1, nodes_metadata_PROP_draw_U1];
                        nodes[n1, nodes_PROP_draw_U1fi] = nodes_metadata[m1, nodes_metadata_PROP_draw_U1fi];
                        nodes[n1, nodes_PROP_U_x] = nodes_metadata[m1, nodes_metadata_PROP_U_x];
                        nodes[n1, nodes_PROP_U_y] = nodes_metadata[m1, nodes_metadata_PROP_U_y];
                        nodes[n1, nodes_PROP_draw_type] = nodes_metadata[m1, nodes_metadata_PROP_draw_type];
                        nodes[n1, nodes_PROP_Font1] = nodes_metadata[m1, nodes_metadata_PROP_Font1];
                        // nodes_properties_calculation(n1);
                    }
                }
            }

        }

    }
}